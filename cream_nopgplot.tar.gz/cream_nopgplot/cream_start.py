import numpy as np
import os
import glob
import sys

#user friendly interface to run cream without having to manually edit all the folders and
#and set up the directory structure. This interface will include all CREAM's basic and 
#advanced customisation options. You can still do it the old way if you prefer just
#ignore this program). 


### CHANGE THE NEXT LINE DEPENDING ON YOUR FORTRAN COMPILER. If using the pgplot version
#! place your pgplot incantation in the pgplot variable below else just leave it blank
compiler = 'gfortran'
pgplot   = ''

compile_command= compiler + ' cream_f90.f90 '+pgplot+' -o creamrun.exe'


#!!!!! default light curve parameters
#DEFAULTS IN misc par for descriptions in miscdesc and also default
#stepsizes for error bar expansion factor:step_se_default
# top hat centroid (for blr light curves): step_thcen_default
# width of the centroid: step_thwid_default
# extra variance factor: step_varexpand_default
miscline = [0,8,9,10,4]
miscdesc = ['directory','fit constant model','upper frequency (cyc/day)','Number of Iterations','Plot Refresh']
miscpar  = ['',-20,0.5,100000,10000]
step_se_default = 0.0
step_thcen_default = 0.0
start_thwid_default  = 0.4
step_thwid_default = 0.0
step_varexpand_default = 0.0
 
pricream_idx=[-1,-2,-3,-4]
pricream_mean = [1.0,30.0,0.75,0.75]
pricream_sd = [-1,-1,-1,-1]

#!!!!! default disk parameters
pname = ['','M_BH', 'Mdot (start)', 'Mdot (step)','inclination (deg) (start)','cosinc (step) [To fit, suggested start stepsize 0.01]','Viscous Tr index step [NOTE: setting equal stepsizes for viscous and irradiating Tr slope ties these parameters together]        ','Iradiation Tr index step [slope starts at -3/4. To fit, suggested start stepsize 0.01]      ']
pval  = ['',1.e7, 0.5, 0.01, 0.0, 0.0,0.0,0.0]
npn   = len(pname)
fname = ['creaminpar_main.par']*(npn-2) + ['creaminpar.par']*2
line  = [0,2,1,1,3,3,72,73]
order = [0,0,0,1,0,1,0,0]



#!!!!!! default prior parameters
pricream_tit  = ['Mdot','inclination', 'Viscous Tr index slope', 'Irradiation Tr index slope'] 
pricream_idx  = [-1,-2,-3,-4]
pricream_mean = [1.0,30.0,0.75,0.75]
pricream_sd   = [-1,-1,-1,-1]


#default otlier rejection parameters
srmode = 1
srk    = 1



#turn offset parameter fixing off by default
pfmode = -1
pfval  = -1

#first of all, cream_start.py copies the creaminpar_dafult.par file into creaminpar.par so that each new run of this code will
#refresh the default parameters comment this out if you want to keep parameters set in earlier runs
#not default creammiscleneous parameters must be set by altering the pardefin parameter in the input to the function cream_readwrite
os.system('clear')
os.system('cp creaminpar_default.par ./creaminpar.par')
os.system('cp creaminpar_main_default.par ./creaminpar_main.par')



dmain = os.getcwd()
lendmain = len(dmain)






 
 
idmain = [i for i in range(len(pname)) if pname[i] == '']
if (len(idmain) == 0):
 idmain = 0
else:
 idmain = idmain[0]
  
#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!
#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!
#!!!!!! define all the subroutines to make the menue and program executions work #!!!!!!

def cs_cus(dnow,exclude=['cream_python'],message_in = '\nto continue a previous simulation...\n',message_out = '\n\nEnter the directory number above: ',idfromto=[0,-1],justlist=0):
 print message_in
 dlist = glob.glob(dnow+'/*/')
 for exnow in exclude:
  dlist = [a for a in dlist if exnow not in a]
 #assign number to each item in list 
 lendlist = len(dlist)
 if (lendlist > 0):
  ida = 0
  for id in range(lendlist):
   print str(id)+') '+dlist[id][idfromto[0]:idfromto[1]] 
  print ''
  if (justlist == 0):
   mo = raw_input(message_out)
   try:
    ida = int(mo)  
    op = dlist[ida]
   except:
    op = mo
 else:
  print 'No sub directories in this folder'
  op = ''
 return(op)  
 
 
 

  
 
def cs_cont():
 abort = 0
 while (done == 0):
  dsub = cs_cus(dmain)
  print '\n\n\n'+dsub
  dversion = cs_cus(dsub,message_in = '\n Versions in this directory ... \n', message_out = 'which version?',idfromto=[0,-19])
  
  if (dversion == 'c'):
   return(abort)
  elif (dversion == 'a'):
   abort = 1
   return(abort)
  else:
   filecopy = ['creaminpar.par','creaminpar_main.par','cream_resume.dat']
   for fnow in filecopy:
    os.system('cp '+dversion+'/'+fnow+' '+dmain)
   os.system('./creamrun.exe')
   return(abort)





#reads creamnames file to figure out how many light curves we have, then makes the
#cream_th.par file
def cs_makethvar(dirmain,step_thcen_default,step_thwid_default):
 
 fname = dirmain+'/creamnames.dat'
 #count number of lines in creamnames.dat file (this is the number of light curves)
 with open(fname) as f:
  for i, l in enumerate(f):
   pass
  f.close()
 nline = i + 1
 
 if (dirmain[-1] == '/'):
  f = open (dirmain + 'cream_th.par','w')
 else:
  f = open (dirmain + '/cream_th.par','w')
  
 for i in range(nline):
  f.write('0.0 '+np.str(step_thcen_default)+' 0.0 -1.0 '+np.str(start_thwid_default)+' '+np.str(step_thwid_default)+' 0.0 -1.0\n')
 f.close()

 return() 
 
 
  
 for i in range(npl):
  f.write(pline[i]+'\n')
 f.close()
 return()







#alter the required files with the new parameters
def cs_change(pnamein,pvalin,fnamein,linein,orderin,change = 1, view = 1, loadview = 0):
 npn = len(pnamein)
 
 #print 'cs_changesdasd'
 ilseen = []
 for i in range(npn):
  pnnow = pnamein[i]
  pvnow = pvalin[i]
  fnnow = fnamein[i]
  lnow  = linein[i]
  onow  = orderin[i]
  idx   = np.array([i2 for i2 in range(npn) if (fnamein[i2] == fnnow) and (linein[i2] == lnow)])
  omulti = np.array([orderin[i2] for i2 in range(npn) if (fnamein[i2] == fnnow) and (linein[i2] == lnow)])
  #sort
  ids = np.argsort(omulti)
  idxsort = idx[ids] 
  display = ''
  display = display.join(np.str(idxsort[i2])+') '+pnamein[idxsort[i2]] + ': '+np.str(pvalin[idxsort[i2]])+'  ' for i2 in range(len(idxsort)))
  if (view == 1 and lnow not in ilseen):
   print display
   ilseen.append(lnow)
   
  if (change == 1):
   with open(fnnow) as f:
     parline = f.readlines()
   parline = [x.strip() for x in parline] 
   f.close()
   npl = len(parline)
   nids = len(ids)
   
   p = ''
   p = p.join( np.str(pvalin[idxsort[i2]])+' ' for i2 in range(nids-1)) 
   
   #print i,npn,nids, pvalin
   #print 'p so far',p
   pann = pnamein[idxsort[nids-1]]
   if (pann == ''):
    p = p + np.str(pvalin[idxsort[nids-1]])#p.join(np.str(pvalin[idxsort[nids-1]])  )
   else: 
    p = p + np.str(pvalin[idxsort[nids-1]])+' !'+pnamein[idxsort[nids-1]] #p.join(np.str(pvalin[idxsort[nids-1]])+' !'+pnamein[idxsort[nids-1]]  )
   #print 'p now',p
   #print pvalin[idxsort[nids-1]],pnamein[idxsort[nids-1]]
   
   
   #for i2 in range(nids-1):
   # print pvalin[idxsort[i2]],'diag'
   
   #raw_input() 

   parline[lnow] = p
   
   
   f = open(fnnow,'w')
   #print fnnow, i
   for plnow in parline:
    f.write(plnow+'\n')
    #print 'writing...',plnow
   f.close()
   
 #raw_input()
 return()
   
  


def cs_func(pname,pval,fname,line,order):
 abort = 0
 done = 0
 os.system('clear')
 cs_change(pname,pval,fname,line,order,change = 0)
 
 while (done == 0):
  idchange = raw_input('Enter a number or "enter" to accept values:')
  
  if (idchange == ''):
   done = 1
   pass
  elif (idchange == 'a'):
   abort = 1
  
  else:
   idchange = int(idchange)
   a = raw_input('Old value: '+np.str(pval[idchange])+'\n Enter new value:')
  
   if (a == 'c'):
    pass
   elif (a == 'a'):
    abort = 1
   else:
    pval[idchange] = np.float(a)
  
  os.system('clear')
  cs_change(pname,pval,fname,line,order,change = 1)

 return(abort)



 for i in range(lpn):
  pnnow = pname[i]
  pvnow = pval[i,:]
  n2 = len(pnow)
  a = ''
  a = a.join(str(i2)+') '+ pnow[i2] +': '+np.str(pvnow[i2]) + '      ' for i2 in range(n2) )
  print a

 return()





def cs_intro():

 abort = 0
 print 'welcome to the cream navigation menu...\n'
 print 'To proceed Place all the light curves for a given target into a sub directory and drop it here:'
 print dmain
 print '\ndirectories within this folder ...'

 print '\n If your directory doesnt appear below, please abort this code and place it here'
 print ''  
 
 
 
 dm = cs_cus(dmain,idfromto=[lendmain,-1],justlist=0,message_in='',message_out='')

 
 if (dm == 'n'): 
  cs_custom(dtarget = '',dirdefault = 'new_simulation')
 elif (dm == 'c' or dm == '' or dm=='a'): 
  abort = 1
 else:
  pval[idmain] = dm 
 
 return(abort)

 


def cs_loadwav(dtarget,file='creamnames.dat'):

 wav_temp = []
 flc_temp = []
 
 
 try:
  with open(dtarget+'/'+file) as f:
   parline = f.readlines()
   parline = [x.strip() for x in parline]
  f.close()
  nlctemp = len(parline) 
  for i in range(nlctemp):
   pl = parline[i].split()
   wav_temp.append(np.float(pl[-1]))
   
   fapp = pl[0]
   if (fapp[0] == '"' or fapp[0] == "'"):
    fapp =fapp[1:]
   if (fapp[-1] == '"' or fapp[-1] == "'"):
    fapp =fapp[:-1]
 
   flc_temp.append(fapp) 

 except:
  print "'creamnames.dat' file not present. Please select which files you want to include in the simulation from the list below"
  print 'target directory: '+dtarget
  print 'Type enter when finished entering light curves.' 
  
  #list and chose from directories
  fpos = next(os.walk(dtarget+'/'))[2]
  more = 1
  nfp = len(fpos)
  wavpos = ['']*nfp
  flc_temp = []
  wav_temp = []
  while more == 1:
   for i in range(len(fpos)):
    if (wavpos[i] == ''):
     print str(i)+')  '+fpos[i]
    else:
     print 'W '+str(i)+')              '+fpos[i] + ' wavlength = '+wavpos[i]
   
   ip = raw_input('\n -->')
   if (ip == ''):
    more = 0 
    continue
   else:
    flc_temp.append(fpos[int(ip)])
    wt = raw_input('Enter wavelength \n -->')
    wav_temp.append(np.float(wt))
    wavpos[int(ip)] = wt
  #finished listing and choosing from directories 
 
 
 
  #make the creamnames file
  f = open(dtarget + '/creamnames.dat','w')
  for ilcn in range(len(flc_temp)):
   f.write("'"+flc_temp[ilcn]+"' "+np.str(wav_temp[ilcn])+'\n')
  f.close()
 
 return(flc_temp,wav_temp)



def cs_custom(dtarget = '',dirdefault = 'new_simulation'):

 if (dtarget == ''):
  version = 2
 else:
  version = 1

 if (version == 2):
  more = 1
  lclist = []
  while (more == 1):
   print 'light curves recorded...'
   for i in range(len(lclist)):
    print lclist[i]
   print ''
   lcnow = raw_input('please enter light curve location or d if done(eg "../../lc1.dat") :') 
   if (lcnow == 'd' or lcnow == ''):
    more = 0
   elif (lcnow == 'c'):
    return()
   else:
    lclist.append(lcnow)
  
  nlc = len(lclist)
  
  wav        = [0]*nlc

  for i in range(nlc):
   if (wav[i] == -1):
    step_thcent[i] = step_thcen_default
  
  
  done = 0
  print 'please enter wavelengths separated by "," for each light curve below. Enter -1 for a line light curve (modelled by a top hat), or 0 to set as driving light curve (one light cuve only).' 
  while (done == 0):
   for i in range(len(lclist)):
    a = raw_input(lclist[i]+'\n-->')
    if (a == 'c'):
     return()
    else:
     wav[i] = np.float(a)
 
 
   #if the required directory structure isnt set up, need to create a directory and deposit 
   #files here
   
   dirdef = glob.glob(dirdefault+'*')
   ndd = len(dirdef)
   ddefname = dirdefault+'_'+str(ndd)
   dsave = raw_input('results will be saved in this directory (within main cream directory)\n: '+ddefname+' \n Type a new subdirectory to change else press enter \n -->')
   if (dsave == ''):
    dsave = ddefname
   
   if (dsave == 'c'):
    return()
   else:
    pval[idmain] = dsave
 
  
   #now save all entered light curves into the new subdirectory
   for i in range(nlc):
    os.system('cp '+lclist[i] + ' ./'+dsave)
   
   
 else:
   
  lclist,wav = cs_loadwav(dtarget,file='creamnames.dat')
  
  
  
  
 nlc = len(wav) 
 sigexpstep = [0]*nlc
 step_thcent = [step_thcen_default]*nlc
 step_varexpand  = [step_varexpand_default]*nlc
 return(lclist,wav, sigexpstep, step_thcent, step_varexpand)






def cs_custom2(lclist,wav,sigexp,step_thcent,step_varexpand):
 done = 0
 nlc  = len(lclist)
 while (done == 0):
  print 'light curve file, wavelength, c'
  for i in range(nlc):
   print 'LIGHT CURVE NUMBER:',i
   if (wav[i] == 0):
    print 'driving light curve!'
   elif (wav[i] == -1):
    print 'top hat response (line light curve)'
   else:
    print 'standard disk light curve' 
   print 'file: ', lclist[i]
   print 'wavelength: ', wav[i]
   print 'error bar expansion factor step size (enter 0 to omit error-bar modification via scaling): ', sigexp[i]
   print 'variance expansion parameter step size (enter 0 to omit error-bar modification via extra variance): ', step_varexpand[i] 
   if (wav[i] == -1):
    print 'top hat response centroid step size', step_thcent[i]
   print ''
   print ''
   
  a = raw_input('if all the above ok type enter, else enter the light curve number to change something\n -->')
  
  if (a  == ''):
   return(lclist,wav,sigexp,step_thcent,step_varexpand)
  else:
   b = raw_input('what do you want to change? \n "f" for file \n "w" for wavelength \n "e" for error bar expansion step size \n "t" for top hat centroid step size (must first set wavelength to -1 \n "v" for extra variance step size \n -->')
   ilc = int(a)
   if (b == 'f'):
    c = raw_input('old ' +lclist[ilc]+'\n enter new file \n -->')
    lclist[ilc] = c
   elif (b == 'e'):
    c = raw_input('old ' +np.str(sigexp[ilc]) + '\n enter new expansion factor step size \n -->')
    sigexp[ilc] = np.float(c)
   elif (b == 'w'):
    c = raw_input('old ' +np.str(wav[ilc]) + '\n enter new wavelength \n -->')
    wav[ilc] = np.float(c)
   elif (b == 't' and wav[ilc] == -1):
    c = raw_input('old '+ np.str(step_thcent[ilc])+ '\n enter new expansion top hat centroid step size \n -->')
    step_thcent[ilc] = np.float(c)
   elif (b == 'v'):
    c = raw_input('old '+ np.str(step_varexpand[ilc])+ '\n enter new extra variance step size \n -->')
    step_varexpand[ilc] = np.float(c)
   else:
    pass

   
 return(lclist,wav,sigexp,step_thcent,step_varexpand)    
   
   
def cs_setlc(dirtargetin,lclistin,wav,sigexp,step_thcent,step_varexpand):
 
 lclist = []
 for ilc in range(len(lclistin)):
  lclist.append(lclistin[ilc])
  if (lclistin[ilc][0] != '"' or lclistin[ilc][0] != "'"):
   lclist[ilc] = "'"+lclist[ilc]
  if (lclistin[ilc][-1] != '"' or lclistin[ilc][-1] != "'"):
   lclist[ilc] = lclist[ilc] + "'"  
 
 if (dirtargetin[-1] =='/'):
  dirtarget = dirtargetin[:-1]
 else:
  dirtarget = dirtargetin 

 pval_lc  = []
 pname_lc = []
 fname_lc = []
 order_lc = []
 line_lc  = []
 
 ice = 0
 nwav = len(lclist)
 senow = ''
 for i in range(nwav):
  #do the wavelengths
  pname_lc.append('')
  fname_lc.append(dirtarget+'/creamnames.dat')
  line_lc.append(i)
  order_lc.append(0)
  pval_lc.append(lclist[i]+' '+np.str(wav[i])) 
  
  #now the top hat step sizes
  pname_lc.append('')
  fname_lc.append(dirtarget+'/cream_th.par')
  line_lc.append(i)
  order_lc.append(0)
  pval_lc.append('0.0 '+np.str(step_thcent[i])+ ' -1.0 -1.0 0.2 0.0 -1.0 -1.0')     
 

  if ((sigexp[i] > 0) and (ice == 0)):     
   pname_lc.append('! sigexpand (Set true to allow error bars to expand with starting step sizes below)')
   fname_lc.append('creaminpar.par')
   line_lc.append(20)
   order_lc.append(0)
   pval_lc.append('T')
   ice = 1 
  senow = senow + ' '+np.str(sigexp[i])
  
  
 #now do the extra variance parameters outside the loop
 pname_lc.append('') 
 fname_lc.append(dirtarget+'/cream_var.par')
 line_lc.append(0)
 a = ''
 for i in range(nwav):
  a = a+np.str(0.0)+' '
 pval_lc.append(a)
 order_lc.append(0)
 
 
 pname_lc.append('') 
 fname_lc.append(dirtarget+'/cream_var.par')
 line_lc.append(1)
 a = ''
 for i in range(nwav):
  a = a+np.str(step_varexpand[i])+' '
 pval_lc.append(a)
 order_lc.append(0) 
 #check if this file is here and if not open and fill with crap
 a = os.path.isfile(dirtarget+'/cream_var.par')
 if (a == 0):   
  f = open(dirtarget+'/cream_var.par','w')
  f.write('-3 \n -3')
  f.close()
  
 #now the sig expansions outside loop
 pname_lc.append('')
 fname_lc.append('creaminpar.par')
 line_lc.append(22)
 order_lc.append(0)
 pval_lc.append(senow)
 
 #write all these into appropriate files
 a = cs_change(pname_lc,pval_lc,fname_lc,line_lc,order_lc,change = 1, view = 0)
  
 return(pname_lc,pval_lc,fname_lc,line_lc,order_lc)
  
  
 
 
 
#script to read in a default parameter file and replace with new set of parameters delimited by ! 
def cs_readwrite(filein,fileout,delim='!',linechange=[0,9,10,4],description=['directory','upper frequency (cyc/day)','Number of Iterations','Plot Refresh'],pardefin=['',0.5,10000,10000],flint = ['c','f','i','i']):
 pardefout = pardefin
 abort = 0
 exclude = ['cream_python/']
 os.system('clear')
 a = 1
 pardef = pardefin
 nchange = len(linechange)
 listdir = ['F']*nchange
 for i in range(nchange):
  if (pardefin[i] == ''):
   listdir[i] ='T'

 
 with open(filein) as f:
  parline = f.readlines()
  parline = [x.strip() for x in parline]
 f.close()
 nlctemp = len(parline)


 while (a != ''): 
  for i in range(nchange):
   print str(i)+') '+description[i]+'. Val='+np.str(pardef[i])
  a = raw_input('\ntype corresponding number to change parameter or enter if nochange:\n-->')
  
  if (a==''):
   continue
  
  elif (listdir[int(a)] == 'T'):
   dlist = glob.glob('*/')
   dlist = [dlnow for dlnow in dlist if dlnow not in exclude]
   ndl = len(dlist)
   for i2 in range(ndl):
    print str(i2)+') '+dlist[i2]
   d = raw_input('press number corresponding to directory to model else abort and place it here:\n-->')
   pardef[int(a)] = dlist[int(d)]
  else:
   ia = int(a)
   b = raw_input('old value='+np.str(pardef[ia])+' please enter new value:\n-->')
   if (flint[ia] == 'f'):
    pardef[ia] = np.str(np.float(b))
   elif (flint[ia] == 'i'):
    pardef[ia] = np.str(np.int(b))
 
 
 for i in range(nchange):
  parline[linechange[i]] = np.str(pardef[i])
  
 
 f = open(fileout,'w')
 
 for i in range(nlctemp):
  f.write(parline[i]+'\n')
 f.close()
 
 pardefout = pardef
 
 return(abort,pardefout) 
 
 



def cs_writeprior(file,pricream_tit,pricream_idx,pricream_mean,pricream_sd):
 nl = len(pricream_idx)
 done_pri = 0
 os.system('clear')
 pricream_mean_out = list(pricream_mean)
 pricream_sd_out = list(pricream_sd)
 
 while (done_pri ==0):
  os.system('clear')
  print 'priors on disc parameters...'
  print ''
  for i in range(nl):
   print np.str(i)+') '+np.str(pricream_tit[i])+'    prior mean:'+np.str(pricream_mean_out[i])+'    prior standard deviation:'+np.str(pricream_sd_out[i])
  print ''
  a = raw_input('Enter number to change prior or "enter" to leave\n -->')
  if (a == ''):
   done_pri = 1
  else: 
   b = raw_input('Old prior mean = '+np.str(pricream_mean_out[int(a)])+'    Old prior standard deviation = '+np.str(pricream_sd_out[int(a)])+'\n Enter new values (mean and sd separated by a space) \n -->')
   bb = b.split()
   pricream_mean_out[int(a)] = np.float(bb[0])
   pricream_sd_out[int(a)]   = np.float(bb[-1])
  
  
  
 f = open(file,'w')
 idxrej = 0
 for i in range(nl):
  pricream_idx_now  = pricream_idx[i]
  pricream_mean_now = pricream_mean_out[i]
  pricream_sd_now   = pricream_sd_out[i]
  #cream requires cos inc information input but inclination more user friendly
  #have user input degrees and convert to cosine here idx -2 corresponds to cosine parameter
  #turn off priors if index = -1
  if (pricream_idx_now == -2 and pricream_sd_now > 0):
   pricream_sd_now   = np.abs(np.sin(pricream_mean_now*np.pi/180)*pricream_sd_now*np.pi/180)
   pricream_mean_now = np.cos(pricream_mean_now*np.pi/180)
   
  if (pricream_sd_now <= 0):
   idxrej = idxrej + 1
   print pricream_idx_now,pricream_mean_now,pricream_sd_now
  else:
   f.write(np.str(pricream_idx_now) + ' ' + np.str(pricream_mean_now) + ' ' + np.str(pricream_sd_now) +'\n')
 f.close()
 
 #if you are not putting any priors on any parameters, then remove the file
 if (idxrej == nl):
  os.system('rm '+file)
 
 
 pricream_mean_out = list(pricream_mean_out)
 pricream_sd_out = list(pricream_sd_out)
 
 
 return(pricream_mean_out,pricream_sd_out)
















def cs_writeparfix(file_creamnames,file_parfix,pfmode_in,pf_in):
 
 lc_sr,wav_sr = cs_loadwav('',file=file_creamnames)
 nl = len(lc_sr)

 if (isinstance(pfmode_in,list) == 1):
  pfmode_out = list(pfmode_in)
 else:
  pfmode_out = [pfmode_in]*nl
  
 if (isinstance(pf_in,list) == 1):
  pf_out = list(pf_in)
 else:
  pf_out = [pf_in]*nl


 
 done_pf = 0
 os.system('clear')

 pfmode_out = [-1]*nl
 while (done_pf ==0):
  os.system('clear')
  print 'Offset parameter fixing'
  print 'set to -1 to allow to vary as normal'
  print ''
  for i in range(nl):
   print np.str(i)+') '+np.str(lc_sr[i])+'    Offset parameter (set -1 to vary as normal):'+np.str(pf_out[i])
  print ''
  a = raw_input('Enter number to change prior or "enter" to leave\n -->')
  if (a == ''):
   done_pf = 1
  else: 
   b = raw_input('Old value = '+np.str(pf_out[int(a)])+'\n Enter new value \n -->')
   
   pf_out[int(a)] = np.float(b)
   
  
  
  
 f = open(file_parfix,'w')
 idxrej = 0
 for i in range(nl):
  pf_now = pf_out[i]
  if (pf_now == -1):
   idxrej = idxrej + 1
  f.write(np.str(pfmode_out[i]) + ' ' + np.str(pf_now)+'\n')
 f.close()
 
 #if you are not putting any priors on any parameters, then remove the file
 if (idxrej == nl):
  os.system('rm '+file_parfix)
 
 

 return(pfmode_out,pf_out)
















def cs_writesigrej(file_creamnames,file_sigrej,srmode_in,srk_in):
 
 lc_sr,wav_sr = cs_loadwav('',file=file_creamnames)
 
 nl = len(lc_sr)
 if (isinstance(srmode_in,list) == 1):
  srmode = list(srmode_in)
 else:
  srmode = [srmode_in]*nl
  
 if (isinstance(srk_in,list) == 1):
  srk = list(srk_in)
 else:
  srk = [srk_in]*nl


 
 done_sr = 0
 os.system('clear')

 
 while (done_sr ==0):
  os.system('clear')
  print 'Light curve outlier rejection mode. Several options..'
  print 'mode 1: Normal treatment.'
  print 'mode 2: points greater than "k" sigma weight only "k" sigma on chi^2'
  print 'mode 3: As 1 but with a smooth transition between chi_i^2 and k^2 for |chi_i| < k'
  print 'mode 4: BOF weighted by |chi_i| rather than chi_i^2 for points with |chi_i| > k.'  
  print ''
  for i in range(nl):
   print np.str(i)+') '+np.str(lc_sr[i])+'    Outlier rejection mode:'+np.str(srmode[i])+'    K (apply rejection criteria to point i if |chi_i| > k) :'+np.str(srk[i])
  print ''
  a = raw_input('Enter number to change prior or "enter" to leave\n -->')
  if (a == ''):
   done_sr = 1
  else: 
   b = raw_input('Old mode = '+np.str(srmode[int(a)])+'    Old k = '+np.str(srk[int(a)])+'\n Enter new values (mode and k separated by a space) \n -->')
   bb = b.split()
   srmode[int(a)] = np.int(bb[0])
   srk[int(a)]   = np.float(bb[-1])
  
  
  
 f = open(file_sigrej,'w')
 idxrej = 0
 for i in range(nl):
  srmode_now = srmode[i]
  srk_now    = srk[i]
  if (srmode_now == 1):
   idxrej = idxrej + 1
  f.write(np.str(srmode_now) + ' ' + np.str(srk_now)+'\n')
 f.close()
 
 #if you are not putting any priors on any parameters, then remove the file
 if (idxrej == nl):
  os.system('rm '+file_sigrej)
 
 
 srmode_out = list(srmode)
 srk_out    = list(srk)
 
 
 return(srmode_out,srk_out)




















 
 
#instruct cream to run on multiple targets one afer another to save having to restart
#dmain is the main cream directory 
# dmulti is the directory containing all sub targets (if different)
def cs_multi(dmain,dmulti_in=-1,thcent_start_in = 0.0,thcent_step_in=0.1, thfwhm_start_in = 0.0, thfwhm_step_in = 0.0, embh_in = 1.e4, emdot_in = 0.01, wavdef_in = 4000.0 ):

 if (dmulti_in == -1):
  dmulti = dmain       
   
 print 'in cs_multi'  
 print 'Do you want to start another set of group simulations or merge completed ones?'
 a = raw_input('1) Start new \n2) Merge\n -->')
 
 if (a == '2'):
  print('directories below...')
 
  fpos = glob.glob(dmulti+'/*/')
  nfp = len(fpos)
  for i in range(len(fpos)):
   print str(i)+')  '+fpos[i]
  
  
  dirsearch = raw_input('\nplease type in a string that encompases all the directories above with targets that you want to merge\n (e.g "multi_run_*")\n -->')
  targsearch = '*/'
  strref = '_spec'
  os.system('cp '+dmain+'/cream_python/multi_merge.py '+dmain)
  os.system('python multi_merge.py '+dirsearch+' '+targsearch+' '+strref)
  os.system('rm '+dmain+'/multi_merge.py')
 else:
  

  print 'listing all target directories within main folder. Please pick the from the list below or type "all" to include all target directories in the multi run'
  #list and chose from directories
  fpos = glob.glob(dmulti+'/*/')
  #fpos = next(os.walk(dmulti+'/'))[2]
  more = 1
  nfp = len(fpos)
  #wavpos = ['']*nfp
  choosepos = [0]*nfp
  fdir_temp = []
  while more == 1:
   for i in range(len(fpos)):
    if (choosepos[i] == 0):
     print str(i)+')  '+fpos[i]
    else:
     print 'Picked '+str(i)+')              '+fpos[i]
   
   ip = raw_input('\n -->')
   if (ip == ''):
    more = 0 
    continue
   elif (ip == 'all'):
    fdir_temp = fpos
    more = 0
   else:
    fdir_temp.append(fpos[int(ip)])
    choosepos[int(ip)] = 1
  #finished listing and choosing from directories 
  #sub directories now listed in choosepos
  
  thcent_start = thcent_start_in
  thcent_step  = thcent_step_in
  thfwhm_start = thfwhm_start_in
  thfwhm_step  = thfwhm_step_in
  emdot = emdot_in
  wavdef = wavdef_in
  embh = embh_in
  #check that the starting parameters for the th and disk are correct
  print ''
  print ''
  print 'you can change the default top hat and continuum parameters below (although the defaults are normally fine)'
  print ''
 
  
  idone = 0
  
  while (idone == 0):
   print ''
   print '1) thcent start, step: ',thcent_start, thcent_step
   print '2) thfwhm start, step: ',thfwhm_start, thfwhm_step
   print '3) embh: ',thcent_start, thcent_step
   print '4) emdot: ',emdot
   print '5) wavdef: ',wavdef 
   print ''
   id = raw_input('Type number to change or enter to pass')
   if (id == '1'):
    a = raw_input('enter new thcent and step parameters (old = '+np.str(thcent_start)+','+np.str(thcent_step)+'):-->\n')
    thcent_start,thcent_step = [float(x) for x in a.split(',')] 
   elif (id == '2'):
    a = raw_input('enter new thfwhm and step parameters (old = '+np.str(thfwhm_start)+','+np.str(thfwhm_step)+'):-->\n')
    thfwhm_start,thfwhm_step = [float(x) for x in a.split(',')] 
   elif (id == '3'):
    a = raw_input('enter new embh (old = '+np.str(embh)+'):-->\n')
    embh = float(a)
   elif (id == '4'):
    a = raw_input('enter new emdot (old = '+np.str(emdot)+'):-->\n')
    emdot = float(a)
   elif (id == '5'):
    a = raw_input('enter new default wav (old = '+np.str(wavdef)+'):-->\n')
    wavdef = float(a)
   elif (id == ''):
    idone = 1
 
  
  #which files to exclude as 'not' light curves
  exclude = [".DS_Store","cream_log.txt","cream_th.par","creamnames.dat","disksimsave.dat","disksimtrop.dat","disksimtropparms.dat"]
  #go into these fdir_temp directories and find number of light curves
  ndir = len(fdir_temp)
  for i in range(ndir):
   fdir_now = fdir_temp[i]
   lc_temp = next(os.walk(fdir_now+'/'))[2]
   lc_temp = [lct for lct in lc_temp if lct not in exclude]
   nlc = len(lc_temp)
   
   #do creamnames folder
   f = open(fdir_now+'/creamnames.dat','w')
   for ilc in range(nlc):
    lcnow = lc_temp[ilc]
    if ('_BLR' in lcnow): 
     wavnow = -1.0
    else:
     wavnow = wavdef
    f.write('"'+lcnow+'" '+np.str(wavnow)+'\n')
   f.close() 
   
   #do cream_th.par folder
   f = open(fdir_now+'cream_th.par','w')
   for ilc in range(nlc):
    f.write(np.str(thcent_start)+' '+np.str(thcent_step)+' -1.0 -1.0 '+np.str(thfwhm_start)+' '+np.str(thfwhm_step)+' -1.0 -1.0 ''\n')
   f.close()
   
   
 
  
  #make a folder multi_run_xx in main containing all choosepos subdirectories
  nmulti = len(glob.glob(dmulti+'/'+'multi_run_*'))
  dmulti_sub = 'multi_run_'+str(nmulti)
  
  dcomb = dmulti+'/'+dmulti_sub
  #print 'dmulti dmultisub ...'+dcomb
  os.system('mkdir '+dcomb)
  #print 'i am copying things to the multi directory'
  for i in range(ndir):
   os.system('cp -rf '+fdir_temp[i][:-1]+' '+dcomb) 
   #print fdir_temp[i][:-1]
  
  #make the creamnames_main.par folder with the starting guesses for the disk parameters
  #print 'here y',dmain + '/creaminpar_main.par'
  f = open(dmain + '/creaminpar_main.par','w')
  f.write(' \n')
  f.write(np.str(emdot)+' 0.0 \n')
  f.write(np.str(embh)+' \n')
  f.write('0.0 0.0 \n')
  f.close()
  
  #copy the rungroup file to the multi directory and run cream
  #print 'here z cp '+dmain+'/cream_python/rungroup.py '+dcomb
  #print 'cp -rf '+dcomb+' '+dmain+'/'
  os.system('cp '+dmain+'/cream_python/rungroup.py '+dcomb)
  os.system('cp -rf '+dcomb+' '+dmain+'/')
  os.chdir(dcomb)
  #print 'ARARRARA',os.getcwd()
  os.system('python rungroup.py')
  os.chdir(dmain)
  
 
 return()

  
  
  


     
def cs_options():

 print 'what do you want to do?'
 print '1) Engage!'
 print '2) View or change input light curve parameters.'
 print '3) View or change input black hole / disk parameters.'
 print '4) Continue a previous run.'
 print '5) Make plots'
 print '6) Change misceleneous parameters'
 print '7) Priors'
 print '8) Apply outlier rejection'
 print '9) Fix offset parameters'
 print 'b) Go back'
 print 'a) Get out of this.'
 a = raw_input(':')
 return(a)
 #print '4) Go to the pub


#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!
#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!
#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!
#!!!!!!#!!!!!!#!!!!!! main program #!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!

#load default file
#parname = 'creaminpar.par'
#with open(parname) as f:
#    parline = f.readlines()
# you may also want to remove whitespace characters like `\n` at the end of each line
#parline = [x.strip() for x in parline] 






done = 0

crcheck = glob.glob('creamrun.exe')
if (len(crcheck) == 0):
 os.system(compile_command)
 
while (done == 0):
 print '1) Single run'
 print '2) Multi run'
 print '3) Change miscelaneous parameters'
 print '4) Make plots'
 print '5) Abort'
 a = raw_input()
 if (a == '1'):
 
  abort = cs_intro()
  firstcustom = 1
  while (abort == 0):
   os.system('clear')
   b = cs_options()
   
   if (firstcustom == 1):
    cs_makethvar(pval[idmain],step_thcen_default,step_thwid_default)
   
   cs_change(pname,pval,fname,line,order,change = 1, view = 0)
   
   if (b == '1'):
    os.system('./creamrun.exe')
   elif (b == '2'):
    #os.system('gfortran cream_f90.f90 ')
    if (firstcustom == 1):
     csc = cs_custom(pval[idmain])
     if (csc == ''):
      continue
     lclist,wav,sigexp,step_thcent,step_varexpand = csc
     firstcustom = 0
    
    lclist,wav,sigexp,step_thcent,step_varexpand = cs_custom2(lclist,wav,sigexp,step_thcent,step_varexpand)
    nlc = len(wav)
    css = cs_setlc(pval[idmain],lclist,wav,sigexp,step_thcent,step_varexpand)
  
    #need to specify cs_change pname, pval, fname, line, order for the lclist, wav, sigexp, step_thcent parameters
    #e.g if making a new cream folder in this routine need to manualy set the creamnames.dat file with all wavelengths and alter sig expand paraters and alter th parameters
    #all that info is contained in the lclist, wav, sigexp, step_thcent parameters that can be passed into the cs_change subroutine just like the disk parameters
    
   elif (b == '3'):
    abort = cs_func(pname,pval,fname,line,order)
   elif (b == '4'):
    print 'continuing previous simulation...'
    abort = cs_cont()
   elif (b == '5'):
    os.system('clear')
    os.system('python make_plots.py')
   elif (b == '6'):
    x = cs_readwrite('creaminpar.par','creaminpar.par',delim='!',linechange=miscline,description=miscdesc,pardefin=miscpar,flint = ['c','i','f','i','i'])
    abort = x[0]
    miscpar = x[1] 
    os.system('clear')
   elif (b == '7'):
    x = cs_writeprior(pval[idmain]+'/pricream.par',pricream_tit,pricream_idx,pricream_mean,pricream_sd)#pricream_idx_out,pricream_mean_out,pricream_sd_out
    pricream_mean,pricream_sd = x[0],x[1]
    os.system('clear')
   elif (b == '8'):
    x = cs_writesigrej(pval[idmain]+'/creamnames.dat',pval[idmain]+'/sigrej.par',srmode,srk)
    srmode = x[0]
    srk    = x[1]
   elif (b == '9'):
    x = cs_writeparfix(pval[idmain]+'/creamnames.dat',pval[idmain]+'/parfix.par',pfmode,pfval)
    pfmode = x[0]
    pfval    = x[1]
   elif (b == 'a'):
    abort = 1
    done = 1
    os.system('clear')
   elif (b == 'b'):
    os.system('clear')
    break
 elif (a == '2'):
  print 'cs_multi'
  abort = cs_multi(dmain)
 
 
 elif (a == '3'):
  x = cs_readwrite('creaminpar.par','creaminpar.par',delim='!',linechange=miscline,description=miscdesc,pardefin=miscpar,flint = ['c','i','f','i','i'])
  abort = x[0]
  miscpar = x[1]
  os.system('clear')
 elif (a == '4'):
  os.system('clear')
  c = raw_input('enter "a" to go back\nenter enter to make plots for all simulations in cream directory\nenter the sub directory path e.g "./test_30deg" (no quotes) to make plots for just those simulations\n--> ' )
  if (c == 'a'):
   continue
  elif (c == ''):
   os.system('python make_plots.py')
  else:
   os.system('python make_plots.py '+c)

 elif (a == '5'):
  done = 1
#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!
#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!
#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!#!!!!!!





 
 

 