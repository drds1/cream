import numpy as np
import os
import glob
import sys

#problem with python plots when running in nohup customize options below to make plots for all 
#or specific targets if dirplot [] then run through all folders in cream directory and try and make
#plots for all. if you have lots of simulation folders within main cream directory then 
#you can just request plots for a subsection of these by altering dirplot list

dirmain = './'
dir_pysubs = './cream_python'

try:
 dpin = sys.argv[1]
except:
 dpin = ''

if (dpin == ''):
 dirplot = []
else:
 dirplot = [dpin]





os.chdir(dirmain)
pwd = os.getcwd()

if (len(dirplot) == 0):
 dp = glob.glob('./*')
else:
 dp = list(dirplot)


for dnow in dp:
 os.chdir(pwd)
 pwdnow = os.getcwd()
 try:
  os.chdir(dnow)
  dps = glob.glob('./*')
  #list all output directories in 
  dps = [d for d in dps if 'output_' in d] 
  for dsub in dps:
   os.chdir(dsub)
   os.chdir('./plots')
   os.system('cp ../../../'+dir_pysubs+'/pyplot_cream_easy_2.py ./')
   os.system('cp ../../../'+dir_pysubs+'/pyplot_parm.py ./')
   os.system('cp ../../../'+dir_pysubs+'/creamconvert.py ./')
   os.system('cp ../../../'+dir_pysubs+'/creamfvg.py ./')
   os.system('cp ../../../'+dir_pysubs+'/cream_pythonsubs.py ./')
   os.system('python pyplot_cream_easy_2.py')
   os.system('python pyplot_parm.py')
   os.system('python creamconvert.py')
   os.system('python creamfvg.py')
   os.system('rm pyplot_cream_easy_2.py')
   os.system('rm pyplot_parm.py')
   os.system('rm creamconvert.py')
   os.system('rm creamfvg.py')
   
   os.chdir('../../')
   
 except: 
  os.chdir(pwdnow)
   
   
   
