#script to remove unwanted files from curent directory folder and plots subfolder to prevent clogging up harddrive
import os

listcrap = ['corgrey_full.PS',
'corgrey_full.PS',
'corgrey_main.PS',
'cream_furparms.dat',
'cream_osparms.dat',
'cream_redcisq.dat',
'cream_sigexpand_parms.dat',
'cream_stretchparms.dat',
'cream_tfparms.dat',
'pythoncov.dat',
'xray_plot_mod.dat',
'cream_fluxflux.dat',
'cream_resume.dat',
'fileinfo.dat',
'outputpars_th.dat',
#'outputpars_varexpand.dat',
'outputpars.dat',
#'outputpars2.dat',
'outputpars3.dat',
'testbofs.dat',
'creaminpar.par']

dcrap = ['plots']

for fnow in listcrap:
 os.system('rm '+fnow)
 
for dnow in dcrap:
 os.system('rm -rf '+dnow)
 
 