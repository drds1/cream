import numpy as np
#import mycorner_jul6_16 as mc
try:
 from cream_pythonsubs import *
except:
 from mycorner_jul6_16 import *
 from myedlum import *


idxres  = [2,3,4]
special = [1,2,0]#is special = 2 take arc cos of data before potting
ibin = 2./3
npoints = -1


#dat = np.loadtxt('/Users/ds207/Documents/standrews/sta/fort/fortcode/mcmcmultiresults/16feb_4151_alls/output_20170228_003/outputpars.dat')

#first off do the accretion disc parameters then try the top hat centroids 
try:
 dat = np.loadtxt('../outputpars.dat')
 
 try:
  ed   = np.loadtxt('cream_miscpar.dat')
  embh = ed[0]
  eta  = ed[1]
 except:
  embh = 1.e7
  eta  = 0.1
 
 
 
 
 
 
 #find if mmdot is varied
 try:
  imdot = np.where(np.array(idxres) == 2)[0][0]
  if (special[imdot] == 1):
   logmmdot = 1
  else:
   logmmdot = 0
 except:
  logmmdot = 0
  imdot = -1
 
 
 
 
 
 
 
 
 nver = np.shape(dat)[0]
 
 
 idxlo = int(np.floor(ibin*nver))
 dat   = dat[idxlo:,idxres]
 nver  = np.shape(dat[:,0])[0]
 nhor = np.shape(dat)[1]
 
 
 #calculate edingon ratios
 #embh = 3.e7
 #eta = 0.1
 
 
 
 
 
 
 
 
 
 ivar = [1]*nhor
 for i in range(nhor):
  idspec = special[i]
  if (idspec == 2):
   dat[:,i] = np.arccos(dat[:,i])*180/np.pi
  if (idspec == 1):
   dat[:,i] = np.log10(dat[:,i])
  
  sd = np.std(dat[:,i])
  if (sd == 0):
   ivar[i]=0
 
 ivar = np.array(ivar)
 idxvar = list(np.where(ivar > 0)[0])
 #idxvar = idxvar[:-1]
 
 dat = dat[:,idxvar]
 
 
 #function to cast number in standard form
 def sci_notation(number, sig_fig=2):
   ret_string = "{0:.{1:d}e}".format(number, sig_fig)
   a,b = ret_string.split("e")
   b = int(b) #removed leading "+" and strips leading zeros too.
   return "$"+a + " \\times 10^" + str(b) +"$"
 
 
 
 if ((embh > 0) or (imdot != -1)):
  if (logmmdot == 1):
   dotm = 10**dat[:,0]
  else:
   dotm = dat[:,0]
  edd_rat = edd(embh,dotm,eta)[2]
  idxsort     = np.argsort(edd_rat)
  ns          = np.shape(idxsort)[0]
  ers         = edd_rat[idxsort]
  idlo        = int(max(0,np.floor(0.17*ns)))
  idhi        = int(min(np.ceil((1.-0.17)*ns),ns-1))
  ermed       = ers[ns/2]
  erlo        = ers[idlo]
  erhi        = ers[idhi]
  siglo       = ermed - erlo
  sighi       = erhi  - ermed
  aner        = ', $L/L_{edd}='+np.str(np.round(ermed,2))+'_{-'+np.str(np.round(siglo,2))+'}^{+'+np.str(np.round(sighi,2))+'}$ for $M_\\mathrm{BH}=$'+sci_notation(embh)+'$M_\odot$'
 else:
  aner = ''
 
 if (npoints == -1):
  iskip = 1
 else:
  iskip = nver/npoints
 
 
 
 #truths = [p0,w0,alpha,beta]
 #annotate = [r'$\dot{M}/M_\odot$yr$^-1$',r'$\cos \left( i \right)$',r'$\alpha$']
 annotate = [r'$\log ( \dot{M}/[M_\odot$yr$^{-1}] )$',r'$i$ $/$ degrees ',r'$\alpha$']
 ann      = [aner,'','']#[aner,'','']
 smpi     = [r'$\log ( \dot{M}/[M_\odot$yr$^{-1}] )$',r'$i$',r'$\alpha$']
 extents=[0.9999,(0.,90.),0.9999]
 
 a = [annotate[i] for i in idxvar]
 b = [smpi[i] for i in idxvar]
 c = [extents[i] for i in idxvar]
 d = [ann[i] for i in idxvar]
 
 #truth_in = [truths[i] for i in idxvar]
 
 #extents=[(0.,1.5),(0.,90.)]
 ann_in   = [annotate[i] for i in idxvar]
 extra_an = [' ' for i in idxvar]#[ann[i] for i in idxvar]
 #a = mc.corner_1(dat,plot_contours=0,sigconts=[100.-68,100.-95,100-99.7],skip = iskip,plot_datapoints=True,
 #sigmedann_pre_in=b,labels=a,extents=[0.99,(0.,90.)],figname = 'parmparmplot.pdf')
 a = corner_1(dat,plot_contours=0,sigconts=[100.-68],skip = iskip,plot_datapoints=True,sigmedann_pre_in=b,sigmedann_post_in = d, labels=a,extents=c,annotate = extra_an, sigmedann=1, xtxtcoord = 0.95,ytxtcoord=1.05, figname = 'parmparmplot.pdf')
except:
 print 'cannot make continuum mdot vs inc posterior plot (maybe no continuum light curves)'
 pass


#try to make line plots of all the varied parameters
try:
 nvar = len(idxvar)
 fig = plt.figure()
 for i in range(nvar):
  ax1 = fig.add_subplot(nvar,1,i+1)
  ax1.plot(dat[:,i])
  ax1.set_xlabel('Iteration')
  ax1.set_ylabel(annotate[i])
 plt.savefig('fig_cream_lines.pdf')
except:
 pass

#now do for the top hat parameters
try:
 npoints = 200
 dat = np.loadtxt('../outputpars_th.dat') 
 nlc = np.shape(dat[0,:])[0]/2
 anthcen = ['lc (cent) '+str(i) for i in range(nlc)]
 anthwid = ['lc (fwhm) '+str(i) for i in range(nlc)]
 
 ann = anthcen + anthwid
 
 
 
 #check which points to plot
 npar = 2*nlc
 idxin = [i for i in range(npar) if np.shape(np.unique(dat[:,i]))[0] > 1]
 dat = dat[:,idxin]
 ann = [ann[i] for i in range(npar) if i in idxin ]
 
 nver = np.shape(dat[:,0])[0]
 iskip = max(1,nver/npoints)
  
 a = corner_1(dat,plot_contours=0,sigconts=[100.-68],skip = iskip,plot_datapoints=True,
 labels=ann, figname = 'parmparmplot_th.pdf')
except:
 print 'cannot make top hat posterior plot (maybe no BLR top hat light curves)'
 pass
