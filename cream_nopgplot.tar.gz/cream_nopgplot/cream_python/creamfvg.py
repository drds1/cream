#NEW 7/6/17 set labels in accompanying file 'creamfvg_extra.py' if required

import numpy as np
import matplotlib.pylab as plt
try:
 from cream_pythonsubs import *
except:
 from mylinfit import *
import matplotlib


#if norm = 1 then do flux flux analysis using normalised units 
#this just tets for linearity. The slopes of any f vs X lines lose their meaning if using this setting
#norm = 1
#all normalisation steps taken in creamconvert.py

# manually set the labels (set lab = []) if using this routine automatically and it wil just use wavelengths as labels
lab     = []
#lab    = [r'$1158\AA$',r'$1367\AA$',r'$1478\AA$',r'$1746\AA$','UVW2','UVM2','UVW1','U','B','V','u','B','g','V','r','R','i','I','z']
#lab    = [r'HST $1158\AA$',r'HST $1367\AA$',r'HST $1478\AA$',r'HST $1746\AA$','Swift UVW2','Swift UVM2','Swift UVW1','Swift U','Swift B','Swift V','u','B','g','V','r','R','i','I','z']




filedrive = 'filedrive.txt'
filelcmod = 'filelcmod.dat'
sig_filelcmod = 'filelcmod_sig.dat'
filelc1 = 'filelcname.txt'

fileos = 'fileos.txt'
col=['purple','darkblue','orange','red','k','purple','darkblue','dodgerblue','orange','red','deeppink','dodgerblue','dodgerblue','g','yellow','orange','red','red','red','k','c','g','b','purple','r','k','c','g','b','purple','r','k','c','g','b','purple']

#col=['r','k','c','g','b','purple','r','k','c','g','b','purple','r','k','c','g','b','purple','r','k','c','g','b','purple','r','k','c','g','b','purple','r','k','c','g','b','purple']
filewav = 'filewav.txt'
fileplot = 'fileplot.dat'

xmin = -4.5
xmax =  5.0
ymin =  0.0
ymax =  30.

ylabfvg = r'$f_\nu \left( \lambda , t \right)$ (mJy)'


font = {'family' : 'normal',
        'size'   : 14}

matplotlib.rc('font', **font)



#load light curve names
with open(filelc1) as f:
 filelc = f.read().splitlines()
 f.close()
 
#load wavelengths
wavs = np.loadtxt(filewav)
wavs = np.append(np.zeros(0),wavs)
if (len(lab) ==0):
 lab = map(str,wavs)
 
nlc    = len(filelc)



#include option to plot in groups (e.g one plot for hst, 1 4 swift and 1 for ground lc's)
try:
 idxplot = np.loadtxt(fileplot)
except:
 idxplot = np.zeros(nlc)

#set labels in accompanying file 'creamfvg_extra.py' if required
try:
 from creamfvg_extra import *
except:
 pass

idxplot_u = np.unique(idxplot)
nplot = np.shape(idxplot_u)[0]





#load driving light curve and sort into ascending flux order
datd = np.loadtxt(filedrive)
isd  = np.argsort(datd[:,1])
datd_s = datd[isd,:]

datlcmod = np.loadtxt(filelcmod)
datlcmod = np.column_stack((np.zeros((np.shape(datlcmod)[0],0)),datlcmod))
idxbad = np.where(datlcmod[:,0] < 0.5)[0]
datlcmod[idxbad,:] = np.nan
#load echo light curve data and interpolate cream x(t) array onto fnu points
datlc = []
xlc   = []
xlc_s = []
i = 0

#load offset and stretch fbar and delta_f parms
datp = np.loadtxt(fileos)
datp = np.vstack((np.zeros((0,4)),datp))

fmod_high = []
fmod_lo   = []
xmod_lo   = []
xmod_high = []
for fnow in filelc:
  datn = np.loadtxt(fnow)
  datlc.append(datn)
  idxnonan = ~np.isnan(datlcmod[:,i])
  
  dlcmodnow = datlcmod[idxnonan,i]
  


  xrms  = np.std(dlcmodnow)
  xmean = np.mean(dlcmodnow)
  #b = (datlcmod[:,i] - xmean)/xrms
  b = (dlcmodnow - xmean)/xrms
  fmod_high.append(np.max(dlcmodnow))
  fmod_lo.append(np.min(dlcmodnow))
  xmod_lo.append(np.min(b))
  xmod_high.append(np.max(b))

  a = np.interp(datn[:,0],datd[idxnonan,0],b)
  #a = 
  
  xlc.append(a) 
  xlc_s.append(np.sort(a))
  i = i + 1

#identify max and min xmod_lo and xmod_max
xmodlolo = min(xmod_lo)
xmodhihi = max(xmod_high)



#xlgal         = xlres[idxz]
#sig_xlgal     = 0#datd_s[idxz,2]
xldiskmin_pre     = datd_s[0,1] 
#sig_xldiskmin = datd_s[0,2] 
xldiskmax_pre     = datd_s[-1,1]
#sig_xldiskmax = datd_s[-1,2]



#make cream fnu vs x(t) plot
xlmin = min(-500,xldiskmin_pre)
xlmax = max(xldiskmax_pre,xmodhihi)
dxl = 0.1
xlres = np.arange(xlmin,xlmax+dxl,dxl)
flineres = []
fline    = []
fig = plt.figure()
ax1 = fig.add_subplot(111)

xplotmin = []
idxpnow = 0


x_s = []
y_s = []
sig_s = []
xplot = np.arange(xlmin,xlmax+dxl,dxl)
yplot_s = []

for i in range(nlc):
 lcnow = datp[i,0] + datd_s[:,1]*datp[i,2]
 fline.append(lcnow)
 
 x   = xlc[i]
 y   = datlc[i][:,1]
 sig = datlc[i][:,2] 
 fit = mylinfitenv(x,y,sig)
 
 
 os = fit[0]
 sigos = fit[1]
 slope = fit[2]
 sigslope = fit[3]
 xbar = fit[-2]
 yplot = os + slope*xplot
 sigyplot = np.sqrt((slope*(xplot - xbar))**2 + sigos**2) 
 xplotmin.append(xplot[np.where(yplot>0)[0][0]])
 #
 flineres.append(datp[i,0] + xlres*datp[i,2])
 x_s.append(x)
 y_s.append(y)
 sig_s.append(sig)
 yplot_s.append(yplot)
 
 #ax1.plot(xlres,flineres[i],label=lab[i],color=col[i])
 #ax1.plot(xplot,yplot,label=lab[i],color=col[i])
 #ax1.plot(xplot,yplot-sigyplot,label=lab[i],color=col[i])
 #ax1.plot(xplot,yplot+sigyplot,label=lab[i],color=col[i])

idxplot = list(idxplot)
for ipu in idxplot_u:
 fig = plt.figure()
 ax1=fig.add_subplot(111)
 idxan = 0
 nu = idxplot.count(ipu)
 dan = (ymax - ymin)/(nu+1)
 anmin = 0.1
 anmax = 0.9
 #dan = (anmax-anmin)/(nu-1)
 ypmax=[]
 for i in range(nlc):
  if (idxplot[i] != ipu):
   continue
  #print ipu,i,idxplot[i]
  ax1.errorbar(x_s[i],y_s[i],sig_s[i],color=col[i],ls='',label=None,marker=None)
  ax1.plot(xplot,yplot_s[i],label=lab[i],color=col[i])
  ypmax.append(yplot_s[i][-1])
  #ax1.text(xmodhihi+0.2,yplot_s[i][-1],lab[i],color=col[i],ha='left')
  #ax1.text(0.83,anmin + dan*idxan ,lab[i],color=col[i],ha='left',transform=ax1.transAxes)
  idxan = idxan + 1
  
 xgallolo = max(xplotmin)
 ax1.plot([xgallolo,xgallolo],[ymin,ymax],color='k')
 ax1.plot([xmodlolo,xmodlolo],[ymin,ymax],color='k')
 ax1.plot([xmodhihi,xmodhihi],[ymin,ymax],color='k')
 ax1.set_xlabel(r'$\int X \left( t - \tau \right) \psi \left( \tau \right) d\tau$')
 ax1.set_ylabel(ylabfvg)
 ax1.set_xlim((xmin,xmax))
 ax1.set_ylim((ymin,max(ypmax)*1.1))
 ax2 = ax1.twiny()
 ax2.set_xlim((xmin,xmax))
 ax2.set_xticks([max(xmin,xgallolo),xmodlolo,min(xmax,xmodhihi)])
 ax2.set_xticklabels([r'$X_\mathrm{gal}$',r'$X_F$',r'$X_B$'])
 
 handles, labels = ax1.get_legend_handles_labels()
 ax1.legend(handles[::-1], labels[::-1])
 plt.tight_layout()
 fileplot = 'fvg_CREAM_plot_'+str(ipu)+'.pdf'
 plt.savefig(fileplot,orientation='portrait')

#os.system('cp '+fileplot+' ../')



#now find accretion disc and host galaxy components using same technique as ICA methods
idxz = np.where(flineres[0] > 0)[0][0] - 1

#xlc_min = []
#xlc_max = []
#for i in range(nlc):
# xlc_min.append(xlc_s[i][0])
# xlc_max.append(xlc_s[i][-1])
# 	
#idmin = np.argmin(xlc_min)
#idmax = np.argmax(xlc_max)
 	
xlgal         = xlres[idxz]
sig_xlgal     = 0#datd_s[idxz,2]
xldiskmin     = datd_s[0,1] 
sig_xldiskmin = datd_s[0,2] 
xldiskmax     = datd_s[-1,1]
sig_xldiskmax = datd_s[-1,2]


idxmin = np.where(xlres > xldiskmin)[0][0]
idxmax = np.where(xlres > xldiskmax)[0][0]

#galaxy spectrum
galspec = []
siggal  = []
for i in range(nlc):
 a = xlgal*datp[i,2]
 siga = a*np.sqrt((sig_xlgal/xlgal)**2 + (datp[i,3]/datp[i,2])**2)
 fnow = datp[i,0] + a
 sigf =  np.sqrt( siga**2 + datp[i,1]**2)
 galspec.append(fnow)
 siggal.append(sigf)
savedat = np.zeros((nlc,3))
savedat[:,0] = wavs
savedat[:,1] = galspec
savedat[:,2] = siggal
np.savetxt('fvg_CREAM_gal.dat',savedat)




#minimum disk spectrum
diskmin    = [] 
sigdiskmin = []
for i in range(nlc):
 a = xldiskmin*datp[i,2]
 siga = a*np.sqrt((sig_xldiskmin/xldiskmin)**2 + (datp[i,3]/datp[i,2])**2)
 fnow = datp[i,2]*(xlres[idxmin]-xlres[idxz])#datp[i,0] + a - galspec[i]
 sigf =  np.sqrt( siga**2 + datp[i,1]**2 +siggal[i]**2)
 diskmin.append(fnow)
 sigdiskmin.append(sigf)
savedat = np.zeros((nlc,3))
savedat[:,0] = wavs
savedat[:,1] = diskmin
savedat[:,2] = sigdiskmin
np.savetxt('fvg_CREAM_diskmin.dat',savedat)



#maximum disk spectrum
diskmax    = [] 
sigdiskmax = []
for i in range(nlc):
 a = xldiskmax*datp[i,2]
 siga = a*np.sqrt((sig_xldiskmax/xldiskmax)**2 + (datp[i,3]/datp[i,2])**2)
 fnow = datp[i,2]*(xlres[idxmax]-xlres[idxz])#datp[i,0] + a - galspec[i]
 sigf =  np.sqrt( siga**2 + datp[i,1]**2 + siggal[i]**2)
 diskmax.append(fnow)
 sigdiskmax.append(sigf)
savedat = np.zeros((nlc,3))
savedat[:,0] = wavs
savedat[:,1] = diskmax
savedat[:,2] = sigdiskmax
np.savetxt('fvg_CREAM_diskmax.dat',savedat)



































