import numpy as np
import matplotlib.pylab as plt
import os
import glob
import matplotlib.gridspec as gridspec
import matplotlib as mpl
from matplotlib import rc
from matplotlib.ticker import AutoMinorLocator
#from mytelid_sort import *
try:
 from cream_pythonsubs import *
except:
 from mytextable import *
from matplotlib.ticker import MaxNLocator


ifs = 15
ifs_drive = 10
fill = 1
textab = 0
#mpl.rcParams['font.family'] = 'serif'
#rc('text', usetex=True) #Enables latex!!
#mpl.rcParams['pdf.fonttype'] = 42   #either 3 or 42, I have no idea why!  do 'ps.fonttype' if you are makinng postscript as well



#dir = '/Users/ds207/Documents/standrews/sta/fort/fortcode/mcmcmultiresults/mcg0811_continuum3/output_20161028_004/plots'
#dir = '/Users/ds207/Documents/standrews/sta/fort/fortcode/mcmcmultiresults/n2617_comb/output_20161028_004/plots'
#dir = '/Users/ds207/Documents/standrews/sta/fort/fortcode/mcmcmultiresults/6814_5aug_ltswift/output_20170218_001/plots/'#/Users/ds207/Documents/standrews/sta/fort/fortcode/mcmcmultiresults/16feb_4151_alls/output_20170217_005/plots/'
dir = './'
#dir  = '/Users/ds207/Documents/standrews/sta/fort/fortcode/mcmcmultiresults/16feb_4151_alls/output_20170217_007/plots/'


#light curves
fname_ve = '../outputpars_varexpand.dat'
fmod = 'modellc.dat'
smod = 'modellc_sig.dat'
filedrive = 'modeldrive.dat'
ftf    = 'modeltf.dat'
stf    = 'modeltf_sig.dat'
filewav   = '../outputpars3.dat'
fileosst  = '../outputpars2.dat'
textable = 'tab_params'#set to '' if dont want table
fileth = '../outputpars_th.dat'
tabcaption = ''
tabname = ''
tabref = ''
iburnin = 2./3#use final 2/3 of mcmc chain to calculate parameters

yticksoff = 0
ytloff = 0
tsub = 0
normunits = 0 #if 1 change yaxis units normalized to mean of each plot
tauplotmax = []
nperplot = 6
lclim = []
cheat = 0
#col = ['indigo','purple','blueviolet','darkblue','mediumblue','b','royalblue','dodgerblue','skyblue','c','mediumseagreen','green','chartreuse','orange','coral','orangered','r']
#col = ['indigo','blueviolet','b','dodgerblue','skyblue','c','blue','c','green','orange','orangered','r']
#col = ['blue','c','green','orange','orangered','r']
col=['indigo','purple','blueviolet','darkblue','mediumblue','b','royalblue','dodgerblue','skyblue','c','mediumseagreen','green','chartreuse','orange','coral','orangered','r']*50

#coltel = ['k','r','b','c','purple','blueviolet','darkblue','mediumblue','b','royalblue','dodgerblue','skyblue','c','mediumseagreen','green','chartreuse','orange','coral','orangered','r']*50
coltel = ['k']*5000

ann = 1#annotate response function with filter name if set to 1 encode this info in the ppcream.py file
#filtername = ['UVW2','UVM2','UVW1',r'$Swift$ u',r'$Swift$ b',r'$Swift$ v','u','g',r'$5100$ $\mathrm{\AA}$','r','i','z']
#filtername = ['u','g',r'$5100$ $\mathrm{\AA}$','r','i','z']
filtername = [' ']*100

plotos = 0
merge = 0 #if merge = 1 then, if we are merging light curves, plot the merged versions
plotres = 1


searchtry= 0#if search try = 0 then just assign number 1,2,3 to different telescopes of same wavleength dont try to group based on file name

samexlim = 1 #use same time limits for x axes on all plots
sepplot  = 1#if 1 then plot all light curves on separate plot even if same wavelength
calc_from_mod = 1#if 1 then use the mean and standard deviation of each model as the offset and stretch parameters rather than the CREAM- inferred offset and stretch parameters



searchstring = ['i_bok_I06_ccd2',
'g_bok_G06_ccd2'
'g_bok_G07_ccd2',
'i_bok_I07_ccd2'
'i_cfht_f1i',
'g_cfht_f1i',
'g_spec',
'i_spec',
'_ha_',
'_hb_',
'cfht_h1',
'cfht_h2',
'bok_G15_ccd4',
'bok_I15_ccd4',
'Liverpool',
'LCOGT-McDonald',
'WMO',
'nKAIT',
'Nickel',
'FTN',
'FTN-old',
'FTN-new',
'Asiago',
'RDS',
'MLO',
]#search for these strings in creamnames file to determine the different telescopes used.


ilcplot = []#specify order of plotting here if empty list then program choses; putting nperplot number of plots per page in creamnames.par order [usually ascending wavelength]
alphapanel = 1#if 1 then label each plot with a letter a -- z for descriptive aid in publications
plotdriver = 1#if 1 then plot the driving light curve on top of the first plot

iexist = os.path.exists('ppcream.py')
if (iexist == 1):
 from ppcream import *


#!!!!!!!!!!#!!!!!!!!!!#!!!!!!!!!!#!!!!!!!!!!#!!!!!!!!!!#!!!!!!!!!!#!!!!!!!!!!
#!!!!!!!!!!#!!!!!!!!!!#!!!!!!!!!!#!!!!!!!!!!#!!!!!!!!!!#!!!!!!!!!!#!!!!!!!!!!
#!!!!!!!!!!#!!!!!!!!!!#!!!!!!!!!!#!!!!!!!!!!#!!!!!!!!!!#!!!!!!!!!!#!!!!!!!!!!
#!!!!!!!!!!#!!!!!!!!!!#!!!!!!!!!!#!!!!!!!!!!#!!!!!!!!!!#!!!!!!!!!!#!!!!!!!!!!









def mytelid_sort(telid):

 a  = list(telid)#[1,2,17,8,1,3,17,5,5,6,8,0,6]
 idasort = np.argsort(a)
 ida_sort_sort = np.argsort(idasort)
 asort = np.array(a)[idasort]
 
 b  = np.arange(np.min(asort),np.max(asort),1)
 c  = np.array(list( set(list(asort)) ^ set( list(b) ) ))
 anew = []
 
 nasort = len(asort)
 
 for i in range(nasort):
  
  anow = asort[i]
  idxless = list(np.where(c < anow)[0])
  idr = 0
 
  if (i < nasort-1):
   anext = asort[i+1]
  if ((anow != 0) & (len(idxless) > 0)):
   
   idxless = list(np.where(c < anow)[0])
   
   idpop = idxless[0]
   
   if (anow != anext):
    d = c[idpop]
    c = np.delete(c,idpop)
    c = np.insert(c,[0],anow)
    c = np.sort(c)
   else:
    d = c[idpop]
   
   anow = d
  

  anew.append(anow)
 
 anew = np.array(anew)[ida_sort_sort]
 
 return(anew)




nss = len(searchstring)




alphabet = 'abcdefghijklmnopqrstuvwxyz'

os.chdir(dir)

fdat = sorted(glob.glob('data_echo_dat_*'))






#load modified errors






#loadwavelengths
#wav=[]
wav = np.zeros((0,3))
try:
 wav = np.vstack((wav,np.loadtxt(filewav)))[:,0]
 wav = list(wav)
 if (sepplot == 1):
  wav = [wav[i] + 0.1*i for i in range(len(wav))]
 
 idx = np.unique(wav,return_index=True)[1]
 wavu = [wav[i] for i in sorted(idx)]
 #print wavu
 #print wav
 #print 'asrarara'
except:
 wav = list(np.arange(nlctot))
 wavu = list(wav)

nlctot  = len(wav)
nlcu    = len(wavu)


#load the the parameters for the blr transfer function


try:
 datth = np.loadtxt(fileth)
 nth   = np.shape(datth[:,0])[0]
 #ibi needed for python 3
 ibi = int(np.floor(iburnin*nth))
 datth = datth[ibi:,:]
 centth = datth[:,:nlctot]
 wideth = datth[:,nlctot:]
 
 centth_med = np.median(centth,axis=0)
 centth_sd  = np.std(centth,axis=0)
 wideth_med = np.median(wideth,axis=0)
 wideth_sd  = np.std(wideth,axis=0)
except:
 centth_med = np.zeros(nlctot)
 centth_sd  = np.zeros(nlctot)
 wideth_med = np.zeros(nlctot)
 wideth_sd  = np.zeros(nlctot)
 







#load entries from creamnames file for telscope identification
tlotemp=-1.e10
thitemp=1.e10
#try:
f = open('../../creamnames.dat')
filedat = f.readlines()
filedat = [i.strip() for i in filedat]#remove \n
wav     = [i.split(' ')[-1] for i in filedat]
wav = [float(x) for x in wav]

wavold = list(wav)
if (sepplot == 1):
  wav = [wav[i] + 0.1*i for i in range(len(wav))]


filedat = [i.split(' ')[0] for i in filedat]

filedat = [i[1:-1] for i in filedat]
f.close()

idx = np.unique(wav,return_index=True)[1]
wavu = [wav[i] for i in sorted(idx)]




#are xrays in this file
yesxray = 0
if (0 in wavu):
 yesxray = 1
 datxray = np.loadtxt('../../'+filedat[0])


#remove wavelength if 0 i.e if xray light curve
wavu = [x for x in wavu if x !=0]
wav = [x for x in wav if x !=0]


nlctot = len(wav)


nlcu=len(wavu)
#find times to use to calculate the offset and stretch parms from model
#only use those with containing continuum light curve data points
idxblr = [i for i in range(len(wav)) if wavold[i] == -1]
ttemp = np.zeros(0)
idctemp = 0

ic = 0
for ftemp in filedat:
 if (idctemp not in idxblr):
  ttemp = np.concatenate((ttemp,np.loadtxt('../../'+ftemp)[:,0]))
  ic = ic + 1
#if only have blr light curves then use those
if (ic == 0):
 for ftemp in filedat:
  ttemp = np.concatenate((ttemp,np.loadtxt('../../'+ftemp)[:,0]))


tlotemp = np.min(ttemp)
thitemp = np.max(ttemp) 
#print 'read creamnames file',wavu
#except:
# filedat = ['file '+np.str(i) for i in range(nlctot)]




#generate the telescope id numbers for this object (or set to zero if not using this feature)
if (nss ==0):
 telid = [0]*nlctot
else:
 telid = []
 for i in range(nlcu):
  wavnow = wavu[i]
  idxwnow = [idxm for idxm in range(nlctot) if wav[idxm] == wavnow]#return indicees of filenames that have the current wavelength
 
  len_idxwnow = len(idxwnow)
  #print wavnow, idxwnow, len_idxwnow
  
  for i2 in range(len_idxwnow):
   fnow = filedat[idxwnow[i2]]
   try:
    telid.append( [idt for idt in range(nss) if searchstring[idt] in fnow][0] )#append the appropriate index of the searchstring if found
   except:
    telid.append(-1)#else assign an erroflag 'no know telescope id'
   
   #print fnow, telid, searchstring
  
 #print telid 
 #raw_input()
 try:
  telidmin = min([i for i in telid if i!= -1])
 except:
  telidmin = 0
  
 #raw_input()
 telid = [x + 1 -telidmin if telid != -1 else 0 for x in telid]#start tel id at 1 (looks better in tabel) assign unknown tel ids to be 0
 
 telid = mytelid_sort(telid)
 
 

#try loading the stretch parameters and offests

try:

 parstosf = np.loadtxt(fileosst)
 npost    = np.shape(parstosf)[0]
 ibn = int(np.floor(iburnin*npost))
 parstosf = parstosf[ibn:,:] 
 parstosmed = np.median(parstosf,axis=0)
 parstossd  = np.std(parstosf,axis=0)
 fmed_save  = parstosmed[2*nlctot:]
 fsd_save   = parstossd[2*nlctot:] 
 
 if (calc_from_mod == 0):
  
  stmed_save = parstosmed[:nlctot]
  stsd_save  = parstossd[:nlctot]
  osmed_save = parstosmed[nlctot:2*nlctot]
  ossd_save  = parstossd[nlctot:2*nlctot]

 else:
  smod_mod = np.loadtxt(smod)
  fmod_mod = np.loadtxt(fmod) 
  osmed_save = []
  ossd_save  = []
  stsd_save  = []
  stmed_save = []
  for i in range(nlctot):
   idxmd = np.where((fmod_mod[:,0] > tlotemp) & (fmod_mod[:,0] < thitemp)& (fmod_mod[:,i+1] != 0))[0]
   nnow  = np.shape(idxmd)[0]
   ossd_now = np.sum( fmod_mod[idxmd,i+1]**2 )/nnow
   osnow  = np.median( fmod_mod[idxmd,i+1] )
   sdnow  = np.std( fmod_mod[idxmd,i+1] )
   sdsd_now = np.sqrt( np.sum( 4*(fmod_mod[idxmd,i+1] - osnow)**2 *(smod_mod[idxmd,i+1]**2 + osnow**2) ) ) /np.sqrt(nnow)
   osmed_save.append(osnow)
   ossd_save.append(ossd_now)
   stmed_save.append(sdnow)
   stsd_save.append(sdsd_now)
  
  osmed_save = np.array(osmed_save)
  ossd_save  = np.array(ossd_save)
  stmed_save = np.array(stmed_save)
  stsd_save  = np.array(stsd_save)
   
  
  
  
 #osmed_save = np.median(fmod_mod,axis=0)
 #ossd_save  = np.sqrt(np.sum(fmod_mod**2,axis=0))
 


 
 for i in range(1,nlctot,1):
  if (stmed_save[i] != stmed_save[i]):
   stmed_save[i] = stmed_save[i-1]
   stsd_save[i] = stsd_save[i-1]
  if (osmed_save[i] != osmed_save[i]):
   osmed_save[i] = osmed_save[i-1]
   ossd_save[i] = ossd_save[i-1]
  if (fmed_save[i] != fmed_save[i]):
   fmed_save[i] = fmed_save[i-1]
   fsd_save[i] = fsd_save[i-1]


 
except:
 stmed_save = np.zeros(nlctot)
 stsd_save  = np.zeros(nlctot)
 osmed_save = np.zeros(nlctot)
 ossd_save  = np.zeros(nlctot)
 fmed_save  = np.zeros(nlctot)
 fsd_save   = np.zeros(nlctot)

res_save=[]

cisqred_save = []
num_save = []
#if no plot order specified (ilcplot  =[]) do it automatically with default number of plots per page = nperplot
def chunks(l, n):
    n = max(1, n)
    return list(list(l[i:i+n]) for i in xrange(0, len(list(l)), n))
    
if (len(ilcplot) == 0):
 ilcp = list(np.arange(nlcu))
 ilcplot = chunks(ilcp,nperplot)



nplot   = len(ilcplot)


if (len(filtername) == 0):
 a =  [' ']*nlctot
 filtername = []
 for i in range(nplot):
  filtername.append(a)











#load info and plot

try:
 varexpand = np.loadtxt(fname_ve)#'../outputpars_varexpand.dat')
 varexpand = np.mean(varexpand,axis=0)
except:
 varexpand = np.zeros(nlctot)




tfplot = np.loadtxt(ftf)
try:
 sigtfplot = np.loadtxt(stf)
except:
 ns = np.shape(tfplot)
 sigtfplot = np.zeros((ns[0],ns[1]))

fplot  = np.loadtxt(fmod)
splot  = np.loadtxt(smod)


tau = tfplot[:,0]
tgrid = fplot[:,0] - tsub



#if yes xray then add a ghost column to the fplot,splot,tfplot,sigtfplot
#if (yesxray==1):
# nfp = np.shape(fplot)[0]
# fplot = np.insert(fplot,1,np.zeros(nfp),axis=1)
# splot = np.insert(splot,1,np.zeros(nfp),axis=1)
# tfplot = np.insert(tfplot,1,np.zeros(nfp),axis=1)
# sigtfplot = np.insert(sigtfplot,1,np.zeros(nfp),axis=1)


#chop off begginning of plots (only plot times after tgrid(1) + tau(Ntau)
tmin = tgrid[3] + tau[-1]
idxtmin = np.where(tgrid > tmin)[0][0]
tgrid = tgrid[idxtmin:]
fplot = fplot[idxtmin:,:]
splot = splot[idxtmin:,:]


ilctot = 0
for iplot in range(nplot):
 #datsave = []
 ilc  = list(ilcplot[iplot])
 filtername_now = [filtername[ih] for ih in ilc]#list(filtername[iplot])
 nlcnow = len(ilc)
 

 #print iplot, [wavu[x] for x in ilc],'xcssfsdfds'
 gs1 = gridspec.GridSpec(nlcnow*4, 4)#if we are includding residual plots these will take up 1/4 of the light curve plot space hence nlcnow*4
 
 
 if ((plotdriver) & (iplot == 0)):
  gs1.update(left=0.1, right=0.9, bottom=0.1,top = 0.7, wspace=0.05,hspace = 0.0)
 else:
  gs1.update(left=0.1, right=0.9, wspace=0.05,hspace = 0.0)
 
 
 idxdown = 0
 
 #if you havent manually set the xplot limits for the response function plots, do it automatically using the mean of the largest wavelength on the current plot
 if (len(tauplotmax) == 0):
  wunow = wavu[ilc[-1]]
  idxnow = [i for i in np.arange(nlctot) if wav[i] == wunow][0]
  tfnow = tfplot[:,idxnow+1]
  tpmaxn = 4*np.sum(tau*tfnow)/np.sum(tfnow)
  #print 'tfnononwonwonwnwnowno',  np.sum(tau*tfnow)/np.sum(tfnow),iplot
  #raw_input()
 else:
  tpmaxn = tauplotmax[iplot]
 
 tpminn = 0
 
 
#determine the light curve plot ranges if no value entered in ppcream.py 
 
 if (samexlim == 1):
  ilctemp = list(np.arange(nlctot))
  nlctemp = nlctot
 else:
  ilctemp = ilc
  nlctemp = nlcnow
  
 if (len(lclim)==0):
  tlcmin = []
  tlcmax = [] 
  for i in range(nlctemp):
   ilcn = ilctemp[i]
   tnow = np.loadtxt(fdat[ilcn])[:,0] - tsub
   tlcmin.append(np.min(tnow))
   tlcmax.append(np.max(tnow))
  xlclo = np.min(tlcmin)
  xlchi = np.max(tlcmax)
 else:
  xlclo = lclim[0]
  xlchi = lclim[1]



 fnowsave = []
 #plot the light curves
 idxtot = 0
 
 #print 'before nlcnow...',nlcnow,i
 for i in range(nlcnow):
  #print 'a'
  
  #if we are plotting blr light curves on same as continuum, make sure tf plots have same range  
  for i2 in range(nlcnow):
   if (wavu[i2] < 0):
    tpminn= tau[0]
    tpmaxn= tau[-1]
  

  #print 'b'
  if (plotres == 0):
   igslo = 4*i
   igshi = igslo + 4
  else:
   igslo = 4*i
   igshi = igslo + 3
  
  #print 'c',igslo,igshi
  ax1 = plt.subplot(gs1[igslo:igshi, 1:])#only 3/4 plot space used for light curve plot if showing residual
  
  
  #print 'd'
  if (plotres == 1):
   axres = plt.subplot(gs1[igshi:igshi+1, 1:])#residual plot
  
  colnow = col[ilctot]
  
  
  wavunow = wavu[ilc[i]]
  idxw = list(np.where(np.array(wav) == wavunow)[0])
  nu = len(idxw)
  
  #print 'e'
  #determine which offset to plot (only matters if there is more than one)
  osmed_u = osmed_save[idxw]
  ossd_u  = ossd_save[idxw] 
  osmed_u_max = np.max(osmed_u)
  idxosmax = np.where(osmed_u == osmed_u_max)[0][0]
  ossd_u_max = ossd_u[idxosmax]
  
  osmed_u_min = np.min(osmed_u)
  idxosmin = np.where(osmed_u == osmed_u_min)[0][0]
  ossd_u_min = ossd_u[idxosmin]
  
  
  #print 'somewhere here'
  tfnow    =  tfplot[:,1+idxw[0]]
  sigtfnow =  sigtfplot[:,1+idxw[0]]
  if (wavunow <= -1):
   tfnow[:] = 0
   sigtfnow[:] = 0
   idx1 = np.where((tau > centth_med[idxtot] - wideth_med[idxtot]) & (tau < centth_med[idxtot] + wideth_med[idxtot]))[0]
   tfnow[idx1] = 1   


  tfnow = tfplot[:,idxw[0]+1]
  
  annow = str(filtername_now[i])
  if (annow == ''):
   annow = r'$'+np.str(int(wavunow))+'\mathrm{\AA}$'
  
  #print wavunow,'annotation'

  #if cheat is on only plot the light curve with the most data points
  if (cheat == 1):
   npoints = []
   for iu in range(nu):
    ilcn = idxw[iu]
    dnow = np.loadtxt(fdat[ilcn])
    npoints.append(np.shape(dnow[:,0])[0])
   iurun = np.argmax(npoints)
   iurun = [iurun]
  else:
   iurun = np.arange(nu)
    
  for iu in iurun:
   ilcn = idxw[iu]
   dnow = np.loadtxt(fdat[ilcn])
   dnow[:,0] = dnow[:,0] - tsub
   idxinc = np.where((fplot[:,0] > tlotemp) & (fplot[:,0] < thitemp) & (fplot[:,0] != 0))[0]
   
   
   #datsave.append(dnow)
   
   sigtfnow = sigtfplot[:,ilcn+1]
   fnow  = fplot[idxinc,ilcn+1]
   snow  = splot[idxinc,ilcn+1]
   sig_exp_now = fmed_save[ilcn]
   var_exp_now = varexpand[ilcn]
   fnowsave.append(fnow)
   
   
    
   #if we are merging light curves, define median offset and stretch parameters to scale all light curves to for plot
   osref = 0.
   osnow = 0.
   stnow = 1.
   stref = 1.
   osnow = osmed_save[ilcn]#np.median(fnow)
   osnow_sd = ossd_save[ilcn]
   stnow    = stmed_save[ilcn]#np.std(fnow)  
   stnow_sd = stsd_save[ilcn]  
   if (merge == 1):
    osref = np.median(osmed_save[idxw])
    stref = np.median(stmed_save[idxw])
    #osnow = osmed_save[ilcn]#np.median(fnow)
    #osnow_sd = ossd_save[ilcn]
    #stnow    = stmed_save[ilcn]#np.std(fnow)  
    #stnow_sd = stsd_save[ilcn]   
#   if (normunits == 1):
#    osref = 0
#    stref = 1
#    osnow = osmed_save[ilcn]#np.median(fnow)
#    osnow_sd = ossd_save[ilcn]
#    stnow = stmed_save[ilcn]#np.std(fnow)  
#    stnow_sd = stsd_save[ilcn]   
    
    
    
    
   
   
   
   ospminlo = osmed_u_min - ossd_u_min
   ospminhi = osmed_u_min + ossd_u_min
   ospmaxlo = osmed_u_max - ossd_u_max
   ospmaxhi = osmed_u_max + ossd_u_max
   if ((normunits ==1) or (merge == 1)):
    dmodmean  = np.mean(fnow) 
    #print wavunow, np.min(dnow[:,0]), np.max(dnow[:,0]),'dfsdfsdf',np.min(dnow[:,1]), np.max(dnow[:,1])
    dnsub     = (dnow[:,1]-osnow)
    dnsub_sd  = np.sqrt(dnow[:,2]**2 + osnow_sd**2)
    b         = stref/stnow
    b_sd      = np.abs(b/stnow)*stnow_sd          
    dnow[:,1] = dnsub*b + osref#(dnow[:,1]-osnow)*stref/stnow + osref
    #dnow[:,2] = dnow[:,2]#dnsub*b * np.sqrt((b_sd/b)**2 + (dnsub_sd/dnsub)**2)#np.sqrt(dnow[:,2]**2 + osnow_sd**2) *stref/stnow
    dplot_0   = dnow[:,2]*b
    dplot_se  = dplot_0 * sig_exp_now
    dplot_al  = b*np.sqrt((sig_exp_now*dnow[:,2])**2 + var_exp_now)
    fnsub     = (fnow - osnow)
    fnsub_sd  = np.sqrt(snow**2 + osnow_sd**2)
    fnow      = fnsub*b + osref
    snow      = snow*b#fnsub*b  * np.sqrt((b_sd/b)**2 + (fnsub_sd/fnsub)**2)
    
    #snow      = snow*stref#/stnow
    
    ospminlo = (ospminlo-osnow)*stref/stnow + osref
    ospminhi = (ospminhi-osnow)*stref/stnow + osref
    ospmaxlo = (ospmaxlo-osnow)*stref/stnow + osref
    ospmaxhi = (ospmaxhi-osnow)*stref/stnow + osref   
   else:
    dplot_0 = dnow[:,2]
    dplot_se = dnow[:,2]
    dplot_al = dnow[:,2] 
    fnow = fnow
    snow = snow
    #fnow      = (fnow-osnow)*stref/stnow + osref


     
   #light curve plots
   #print 'light curve plots...',telid,colnow
   #print wavunow,colnow,fnow[0]-snow[0]
   #print ''
   
   if (searchtry == 1):
    coltelnow = coltel[telid[idxtot]]
   else:
    coltelnow = coltel[iu]
   
   #print 'plotting errorbars...',np.min(dnow[:,0]),np.max(dnow[:,0]), np.min(dnow[:,1]), np.max(dnow[:,1]), osnow,stnow,osref,stref#np.median(dnow[:,1]), np.std(dnow[:,1]),osnow,stnow,osref,stref
   #print 'first 10 points...'
   #print dnow[:10,0]
   #print dnow[:10,1]
   #print dnow[:10,2]
   #print ''
   
   #plot all error bars including cream-expanded ones. Decide which order to plot them in 
   
   
   #try plotting 'rejected' points by looking for 4th column in dnow file
   try:
    sigrej = dnow[:,3]
    idrej = np.where(sigrej == 1)[0]
    ax1.scatter(dnow[idrej,0],dnow[idrej,1],color='r',marker='o')
   
   idx_ord = 2 - np.argsort([dplot_0[0],dplot_se[0],dplot_al[0]])
   ax1.errorbar(dnow[:,0],dnow[:,1],dplot_0 ,color='k',ls='',mew=1,capsize=0.5,zorder=idx_ord[0])
   ax1.errorbar(dnow[:,0],dnow[:,1],dplot_se,color='r',ls='',mew=1,capsize=0.5,zorder=idx_ord[1])
   if (var_exp_now != 0):
    ax1.errorbar(dnow[:,0],dnow[:,1],dplot_al,color='b',ls='',mew=1,capsize=0.5,zorder=idx_ord[2])
   
   
   if (iu >= 0):
    ax1.plot(tgrid[idxinc],fnow,color=colnow)#help
    if (fill == 1):
     ax1.fill_between(tgrid[idxinc],fnow-snow,fnow+snow,color=colnow,alpha=0.2)
    else:
     ax1.plot(tgrid[idxinc],fnow+snow,color=colnow)   
     ax1.plot(tgrid[idxinc],fnow-snow,color=colnow) 
   ndnow = np.shape(dnow[:,0])[0]
   res_now = dnow[:,1] - np.interp(dnow[:,0],tgrid[idxinc],fnow) 
   cisqred_save.append(np.sum((res_now/dnow[:,2])**2) / ndnow)
   res_save.append( res_now )
   num_save.append( ndnow )
   
   
   if (plotres == 1): 
    axres.errorbar(dnow[:,0],res_now,dplot_0 ,color=coltelnow,ls='',mew=1,capsize=0.5,marker=None,zorder=idx_ord[0])
    axres.errorbar(dnow[:,0],res_now,dplot_se,color=coltelnow,ls='',mew=1,capsize=0.5,marker=None,zorder=idx_ord[1])
    if (var_exp_now != 0):
     axres.errorbar(dnow[:,0],res_now,dplot_al,color=coltelnow,ls='',mew=1,capsize=0.5,marker=None,zorder=idx_ord[2])
    axres_xlim = list(axres.get_xlim())
    axres.plot([xlclo,xlchi],[0.,0.],color='k')
    
   idxtot = idxtot + 1
   
  #plot max and min offsets if plotos
  if (plotos == 1):
   ax1.plot([xlclo,xlchi],[ospminlo,ospminlo],color=coltel[idxosmin])
   ax1.plot([xlclo,xlchi],[ospminhi,ospminhi],color=coltel[idxosmin])
   ax1.plot([xlclo,xlchi],[ospmaxlo,ospmaxlo],color=coltel[idxosmax])
   ax1.plot([xlclo,xlchi],[ospmaxhi,ospmaxhi],color=coltel[idxosmax])

   
  #transfer function plots 
  if (plotres == 0):
   ax2 = plt.subplot(gs1[igslo:igshi, 0])#tfplot
  else:
   ax2 = plt.subplot(gs1[igslo:igshi+1, 0])#tfplot
  
  tflo   = tfnow-sigtfnow
  tfhi   = tfnow+sigtfnow
  if (wavunow > 0):#if we have blr light curves plot histogram of time delay centroid parameters, else plot mean +/- sd transfer function
   ax2.plot(tau,tfnow,color=colnow)
   if (fill == 1):
    ax2.fill_between(tau,tflo,tfhi,color=colnow,alpha = 0.2)
   else:
    ax2.plot(tau,tflo,color=colnow)
    ax2.plot(tau,tfhi,color=colnow)
  else:
   #print 'plotting hist',ilcn
   ax2.hist(centth[:,ilcn],bins=50,color=colnow)
  
  #mean delays
  ylim = list(ax2.get_ylim())
  dello  = np.sum(tau*tflo)/np.sum(tflo)
  #delmid = np.sum(tau*tfnow)/np.sum(tfnow)
  
  delhi  = np.sum(tau*tfhi)/np.sum(tfhi)
  delmid = (delhi + dello)/2
  
  if (wavunow > 0):#if continuumnot line
   centth_med[idxw] = delmid
   centth_sd[idxw]  = (delhi-dello)/2 

  
  ax1.yaxis.tick_right()
  ax1.yaxis.set_label_position("right")
  
  
  
  
  
  
  
  
  if ((iplot == 0) and (iu == 0)):
   ax1.xaxis.set_major_locator(MaxNLocator(5))
   ax_t = ax1.get_xticks()
   ax1.set_xticks(ax_t)
   axres.set_xticks(ax_t)
  #ticks and labels
  
  #label plot with filtername
  if (ann==1):
   #annow = filtername[ilctot]
   
   ax2.text(0.9,0.7,annow,ha='right',transform=ax2.transAxes)
  
  #x axis tics for response functions and light curves overlap, remove the first x tick label from the light cucrve plots
  #xt = ax1.get_xticks()
  #xt = xt[1:]
  #xtlab = [''] + [str(int(x)) for x in xt]
  
  #ax1.set_xticklabels(xtlab)

  #print 'i fucing hate esicence', i, nlcnow, plotres, iplot
  if (plotres==1):
   axres.set_xticklabels([])
   
  if (i < nlcnow -1):
   ax1.set_xticklabels([])
   ax2.set_xticklabels([])
   #print 'option 1'
  elif ((plotres == 1) & (i == nlcnow - 1)):
   ax1.set_xticklabels([])
   atic = axres.get_xticks()
   
   #axres.set_xticks(atic)
   axlab = [str(int(x)) for x in atic]
   axres.set_xticklabels(axlab)
   #print xt,'arararar',xlclo,(xt[1] - xt[0])/4
   #if ((xt[0] - xlclo) < ((xt[1] - xt[0])/4)):
   # #print 'this is true'
   # xtlab[1] = ''
   #axres.set_xticklabels(xtlab)
   axres.set_xlabel('Time (HJD - 2,456,000)',fontsize=ifs)
   ax2.set_xlabel('Delay (days)',fontsize =ifs)
   #print 'option 2'
  elif ((plotres == 1) & (i < nlcnow-1)):
   axres.set_xticklabels([])
   #print 'option 3'
  else:
   ax1.set_xlabel('Time (HJD - 2,456,000)',fontsize =ifs)
   ax2.set_xlabel('Delay (days)',fontsize =ifs)
   #print 'option 4'
   
  if (plotres == 1): 
   axres.set_yticklabels([])
  
 
   
  if (i == nlcnow/2):
   ax1.set_ylabel('flux (arbitrary units)',fontsize =ifs)
   ax2.set_ylabel(r'$\psi \left( \tau \right)$ (arbitrary units)',fontsize =ifs)
   
  ax2.set_yticklabels([])
  ax2.tick_params(axis='y',which='minor',bottom='off')
  ax2.tick_params(axis='x',which='minor',bottom='on')
  a2yl = list(ax2.get_ylim())
  ax2.set_ylim([0,a2yl[-1]])
  
  
  #if (wavunow == -1):#change plot limits if dealing with line ligth curve
   #tpminn = tau[0]
   #tpmaxn = tau[-1]
   
  
  ilctot = ilctot + 1
  yt = ax1.get_yticks()
  yt = yt[::2]
  yt = yt[1:-1]
  ax1.set_yticks(yt)
  

  if (yticksoff==1):
   ax1.set_yticks([])
  if (ytloff):
   ax1.set_yticklabels([])
  ax2.set_xlim([tpminn,tpmaxn])
  
   
  #too many xticks for response function plots (they interfere) remove everyother ticks
  #default miscellaneous plotting parameters number of ticks, minor ticks, label positions etc 
  
  xt = ax2.get_xticks()
  xt = xt[::2]
  ax2.set_xticks(xt)
  
  ax2.plot([dello,dello],[ylim[0],ylim[1]],color=colnow)
  ax2.plot([delmid,delmid],[ylim[0],ylim[1]],color=colnow)
  ax2.plot([delhi,delhi],[ylim[0],ylim[1]],color=colnow)
  max_yticks = 4
  yloc = plt.MaxNLocator(max_yticks)
  ax1.yaxis.set_major_locator(yloc)
  
  
  yt = ax1.get_yticks()
  ytl = ax1.get_yticklabels()
  
  
  #special case overlapping ticks
  if (ilctot == 3):
   yt = yt[2:]
  else: 
   yt = yt[1:-1]
   
  ax1.set_yticks(yt)
  
  ax1.xaxis.set_minor_locator(AutoMinorLocator(5)) 
  ax1.yaxis.set_minor_locator(AutoMinorLocator(2)) 
  ax2.xaxis.set_minor_locator(AutoMinorLocator(2))   







  ax1.set_xlim([xlclo,xlchi])
  if(plotres == 1):
   axres.set_xlim([xlclo,xlchi])
  #if alphapannel on then label each panel
  if (alphapanel ==1):
   if ((plotdriver ==1) & (iplot == 0)):
    ax2.text(0.9,0.1,'('+alphabet[i+1]+')',ha='right',transform=ax2.transAxes,fontweight='bold')
    ax1.text(0.03,0.1,'('+alphabet[i+nlcnow+1]+')',ha='left',transform=ax1.transAxes,fontweight='bold')
   else:
    ax2.text(0.9,0.1,'('+alphabet[i]+')',ha='right',transform=ax2.transAxes,fontweight='bold')
    ax1.text(0.03,0.1,'('+alphabet[i+nlcnow]+')',ha='left',transform=ax1.transAxes,fontweight='bold')


#plot driver if necessary 
 xlim = ax1.get_xlim()
 if ((plotdriver ==1) & (iplot == 0)):
   gsd = gridspec.GridSpec(1,4)
   gsd.update(left=0.1, right=0.9, bottom=0.75,top = 0.9,wspace=0.05, hspace=0.0)
   ax1 = plt.subplot(gsd[0, 1:])
   if (yesxray == 1):
    ax1.errorbar(datxray[:,0],datxray[:,1],datxray[:,2],ls='',color='r')
   fdrive = np.loadtxt(filedrive)
   fdrive[:,0] = fdrive[:,0] - tsub
   fdrivemean = np.mean(fdrive[:,1])
   fdriverms  = np.std(fdrive[:,1])
   fdrivenow = fdrive[:,1]
   fdrivelo   = fdrive[:,1]-fdrive[:,2]
   fdrivehi   = fdrive[:,1]+fdrive[:,2]
   if (yesxray == 0):
    fdrivelo   = (fdrivelo - fdrivemean)/fdriverms + fdrivemean
    fdrivehi   = (fdrivehi - fdrivemean)/fdriverms + fdrivemean  
    fdrivenow = (fdrivenow - fdrivemean)/fdriverms + fdrivemean
   
   ax1.plot(fdrive[:,0][idxinc[0]:],fdrivenow[idxinc[0]:],color='k')
   
   if (fill == 1):
    ax1.fill_between(fdrive[:,0][idxinc[0]:],fdrivelo[idxinc[0]:],fdrivehi[idxinc[0]:],alpha=0.2,color='k')
   else:
    ax1.plot(fdrive[:,0][idxinc[0]:],fdrivelo[idxinc[0]:],color='k')
    ax1.plot(fdrive[:,0][idxinc[0]:],fdrivehi[idxinc[0]:],color='k')
   ax1.set_xlim(xlim)
   ax1.set_xticklabels([])
   ax1.set_ylabel('X(t) (arbitrary units)',fontsize =ifs_drive)
   ytldrive = list(ax1.get_yticks())
   ytldrive = []#[str(i) for i in ytldrive]
   #ytldrive[::2] = ''
   #ax1.set_yticklabels(ytldrive)
   
   if (alphapanel == 1):
    ax1.text(0.03,0.1,'('+alphabet[0]+')',ha='left',transform=ax1.transAxes,fontweight='bold') 
   #ax1.set_xlim([600,810])
 #plt.show()  
 ax1.xaxis.set_minor_locator(AutoMinorLocator(5)) 
 
 
 
 
 
 #check the plot file exists if it does make another 
 idp = 0
 fileplot = os.getcwd()+'/save_'+str(idp)+'_pyplot_cream_'+str(iplot)+'.pdf'
 exists = 1
 while (exists == 1):
  idp = idp + 1
  fileplot = os.getcwd()+'/save_'+str(idp)+'_pyplot_cream_'+str(iplot)+'.pdf'
  exists = os.path.exists(fileplot)
  #print fileplot
 
 print 'Saving plot now...',fileplot
 
 plt.savefig(fileplot,orientation='portrait')
 

 
 #os.system('cp '+fileplot+' ../')
 #raw_input()
 #plt.savefig('cream_n26_'+str(iplot+1)+'.pdf',orientation='portrait')

 

#make a latex table of the offset, stretch and f parameters
if (textable != ''):
 colhead  = ['Tel I.D','Wavelength','$\\langle \\tau \\rangle$','os','st','f','$\\chi^2/n$','n']
 colunits = ['','$\\mathrm{\\AA}$','(days)','','','','']
 ndp = [0,0,2,2,2,2,2,0]
 #npost    = np.shape(parstosf)[0]
 #parstosf = parstosf[iburnin*npost:,:]
 #parstosmed = np.median(parstosf,axis=0)
 #parstossd  = np.std(parstosf,axis=0)
 #stmed_save = parstosmed[:nlctot]
 #stsd_save  = parstossd[:nlctot]
 #osmed_save = parstosmed[nlctot:2*nlctot]
 #ossd_save  = parstossd[nlctot:2*nlctot]
 #fmed_save  = parstosmed[2*nlctot:]
 #fsd_save   = parstossd[2*nlctot:]
 
 
 #generate arrays for table
 dattab_med = np.zeros((nlctot,8))
 dattab_med[:,0] = telid
 dattab_med[:,1] = wav
 dattab_med[:,2] = centth_med
 dattab_med[:,3] = osmed_save
 dattab_med[:,4] = stmed_save
 
 nf = np.shape(fmed_save)[0]
 for i in range(nf):
  if (fmed_save[i]==0):
   fmed_save[i] = 1
   fsd_save[i] = -1
 dattab_med[:,5] = fmed_save
 dattab_med[:,6] = cisqred_save
 dattab_med[:,7] = num_save
 
 
 dattab_sd  = np.zeros((nlctot,8)) 
 dattab_sd[:,0] = -1.0
 dattab_sd[:,1] = -1.0
 dattab_sd[:,2] = centth_sd
 dattab_sd[:,3] = ossd_save
 dattab_sd[:,4] = stsd_save
 dattab_sd[:,5] = fsd_save
 dattab_sd[:,6] = -1.0
 dattab_sd[:,7] = -1.0
 
 str_replace = ['']*8
 str_replace [0]=[x[:-4] for x in filedat]
 
 if (textab == 1):
  a = mytextable(datin = dattab_med, datsd = dattab_sd,colheadin = colhead,colunits=colunits,ndpin=ndp,str_rep_in = str_replace,caption=tabcaption,opfile=tabname,tabref=tabref)

 
 
 


 
 

