import glob
import os

#run cream on a group of light curves without having to manually start each target
#enter directories manually or just drop this file in a folder that has the list of directories init
dirmain = ''
dirs = []

#new approach dont have to manually enter cream directory just assume that this is one subfolder in
#then just need to climb up 1 and list pwd
#dircream = '/Users/ds207/Documents/standrews/sta/fort/fortcode/mcmcmulti3'
a = os.getcwd()
os.chdir('../')
dircream = os.getcwd()
os.chdir(a)




creamfile = 'creaminpar.par'#'creaminpar_main.par'#
idxline=0







def find(str, ch):
    for i, ltr in enumerate(str):
        if ltr == ch:
            yield i

pwd = os.getcwd()
if (len(dirs) == 0):
 d='.'
 dirs = [os.path.join(d,o) for o in os.listdir(d) if os.path.isdir(os.path.join(d,o))]
 dirmain = str(pwd)
ndir = len(dirs)


os.chdir(dircream)
for i in range(ndir):
 #print 'hererere'
 os.system('cp -rf '+pwd+dirs[i][1:] +' ./ ')
 #print 'thetete','cp -rf '+pwd+dirs[i][1:] +' ./ ' 
 
 with open(creamfile) as f:
  lines = f.read().splitlines()
 f.close()
 nline = len(lines)
 idxslash = dirs[i].index('/')
 newtarget = '.'+dirs[i][idxslash:]
 lines[idxline]=newtarget
 f = open('creaminpar_temp.par','w')
 for i in range(nline):
  f.write(lines[i]+'\n')
 f.close()
 os.system('cp creaminpar_temp.par '+creamfile)
 
 os.system('./creamrun.exe')
 #remove read statements from cream or it will get stuck
 os.system('cp -rf '+newtarget+' '+dirmain)
 
 
 
 