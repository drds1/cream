#script to take the results from cream, make ne light curs based on the offset, stretch and error bar rescaling factors
#the transformation applied to each light curve for any 1 targe is as follows
#!!!!!!Let the CREAM calibration parameters for the reference lightcurve be
#!!!!!!<or> = flux offset,  <sr> = flux stretch,  <er> = error bar scale factor.
#!!!!!!If a flux datum is dat +/- sig, then the required transformation is
#!!!!!!dat -> ( dat - <o> ) <sr> / <s> + <or>
#!!!!!!sig -> sig <e> <sr> / <s>
#version 2 save relevant plot file (for putting on website where you dont want people accessing data), version 3 save plots and data files (for sending via email)



import numpy as np
import glob
import os
import matplotlib.pylab as plt
import sys
import re
#import mydiptest_2 as md2

try:
 from cream_pythonsubs import *
except:
 from myredcisq import *
 from mytextable import *
 from mystats import *


sub2min = 1



#/Users/ds207/Documents/standrews/sta/fort/fortcode/lucky_results
dirsearch  = './katelc_group_1febmerge_3*'#sys.argv[1]
targsearch = 'rm*'#sys.argv[2]
strref     = 'spec_i'#sys.argv[3]
#customizeable options for this routine (eventually set as arguments or make a function)
#dirsearch = 'multi_run*'
#targsearch = '*/'#'rm*'
dirmergesave = 'multi_merged_comb'
#strref = '_spec'
dirres = os.getcwd()#'/microlens/ds207/fortcode/mcmcmulti3/'##'/Users/ds207/Documents/standrews/sta/fort/fortcode/lucky_results/' 



dipteston = 0
test = 0#if test == 1then only use first katelc_ group and first target of that group
dirall = []

version = 3

showplot = 0

#



thparmeansave = []
thparmeangori = []
thparrmssave = []
thfailsave    = []
thparsnrhb    = []
thparmeanname = []
redcisqsave       = []
redcisqname   = []
diptestsave = []
pwd = os.getcwd()
if (len(dirall) == 0):
 dirall = glob.glob(dirres+'/'+dirsearch)

if (test ==1):
 dirall = [dirall[-1]]#when testing this just use first target for speed 


nd = len(dirall)



targetfail = []
datsum = ['directory	lightcurve		offset		1sig		stretch		1sig		f		1sig \n']
#change to target directory and make merged light curves (1 for each telescope and one combined light curve)
for i1 in range(nd):
 os.chdir(dirall[i1])
 
 dirtarget = glob.glob(targsearch)#list all targets in group
 if (test == 1):
  dirtarget = [dirtarget[-1]]
 
 ntarget = len(dirtarget)
 print 'herererer', os.getcwd()
 for i2 in range(ntarget):
  idxblr = []
  print i2,ntarget,dirtarget[i2],os.getcwd(),dirall[i1],nd,'arararar'
  os.chdir(dirtarget[i2])
  try:
   print 'step 1'
   f = open('creamnames.dat')
   #except:
   # targetfail.append(dirtarget[i2])
    #continue
   filedat = f.readlines()
   filedat = [i.strip() for i in filedat]#remove \n
   wav     = [i.split(' ')[-1] for i in filedat]
   wav = [float(x) for x in wav]
 
   print 'step 2'
   filedat = [i.split(' ')[0] for i in filedat]
   filedat = [i[1:-1] for i in filedat]
   f.close()
   
   #find lowest and largest times
 
   #print 'tlo hi temp...',tlotemp,thitemp
   #raw_input()
   
   
 
   #ir = 0
   #for f in filedat:
   # idxcoma = [pos for pos, char in enumerate(f) if char == "'"]
   # filedat[ir] = f[idxcoma[0]+1:idxcoma[1]]
    
   #load the hbeta light curve and calculate the snr
   #try:
   # lchb  = glob.glob('*_hb_*')[0]
   # dathb = np.loadtxt(lchb)
   # snrhb = (np.max(dathb[:,1]) - np.min(dathb[:,1]))/np.median(dathb[:,2])
   #except:
   # snrhb = np.nan
   
   # 
   #filedat = [i[1:] for i in filedat]#remove extra '" at staart of string
   nlc = len(filedat)
   
   
   for idb in range(nlc):
    if (('_hb_' in filedat[idb]) or ('_ha_' in filedat[idb]) or ('_mg2' in filedat[idb])):
     idxblr.append(idb)
   
   print 'step 3'
   #find times to use to calculate the offset and stretch parms from model
   #only use those with containing continuum light curve data points
   ttemp = np.zeros(0)
   idctemp = 0
   for ftemp in filedat:
    if (idctemp not in idxblr):
     ttemp = np.concatenate((ttemp,np.loadtxt(ftemp)[:,0]))
   tlotemp = np.min(ttemp)
   thitemp = np.max(ttemp) 
   
   dirnow_target = os.getcwd()
   
   if ('_i' in dirnow_target):
    gori = 2
   else:
    gori = 1
    
   #print dirnow_target,'arara', gori 
  
   #raw_input()
  
   idxref = 0#define a reference light curve for rescaling
   creamdirpos_pre = glob.glob('output_*')
   creamdirpos = [float(''.join(re.findall('\d+',sr))) for sr in creamdirpos_pre]
   idxrecent = np.argsort(creamdirpos)[-1] 
   #remove old runs to save space
   ndpos = len(creamdirpos)
   creamdir = creamdirpos_pre[idxrecent]
   os.chdir(creamdir)
   
   print 'now in ',os.getcwd()
   #print 'changing to ',creamdir
   print 'listing shit'
   os.system('ls')
   ospref = np.loadtxt('cream_osparms.dat')
   stpref = np.loadtxt('cream_stretchparms.dat')
   erp = np.loadtxt('cream_sigexpand_parms.dat',skiprows=1)
   thexpand  = np.loadtxt('outputpars_th.dat')
   nvw = np.shape(thexpand[:,0])[0]
   try:
    varexpand = np.loadtxt('outputpars_varexpand.dat')
   except:
    varexpand = np.zeros((nvw,nlc))
   print 'after loading'
  
   
   
   ve = np.mean(varexpand[2./3*nvw:,:],axis=0)
   #osr = 1.*osp[idxref,:]
   #str = 1.*stp[idxref,:]
   #err = 1.*erp[idxref,:]
   datcomb = np.zeros((0,5))
   
   #find index with largest rms. This is the one that is the hebtal th lag
   #rms = np.std(thexpand,axis=0)
   #idxmax = np.argmax(rms)
   thparsub = []
   thparsubrms = []
   diptestsub = []
   #print 'before here', idxblr, filedat
   
   ext = ''
   for idb in idxblr:
    thpar = thexpand[2./3*nvw:,idb]
    
    print  'blablabla start',idb, ext, idxblr
    
    dathb = np.loadtxt('../'+filedat[idb])
    snrhb = (np.max(dathb[:,1]) - np.min(dathb[:,1]))/np.median(dathb[:,2])
    
    print  'blablabla middle',idb, ext, idxblr
    
    if ('_ha_' in filedat[idb]):
     ext=' ha '
    elif('_mg2' in filedat[idb]):
     ext=' mg2 '
    else:
     ext=' hb '
   #check for failures or save the lag info
    if (np.std(thpar[:-100:]) ==0):
     thfailsave.append(dirnow_target)
    else:
   #
    
     print  'blablabla next',idb, ext, idxblr, dipteston
     if (dipteston == 1):
      diptest = 0#md2.DipTest(thpar)[0]
     else:
      diptest = 0
     diptestsub.append(diptest)
     diptestsave.append(diptest)
     thparmean = np.mean(thpar)
     
     print  'blablabla next next',idb, ext, idxblr, diptest
     #thparrms  = np.std(thpar)
     thparrms = np.abs(stat_uncert(thpar)[1])
     
     print  'blablabla next next next',idb, ext, idxblr, diptest
     thparsub.append(thparmean)
     thparsubrms.append(thparrms)
     thparmeansave.append(thparmean)
     thparrmssave.append(thparrms)
     thparmeangori.append(gori)
     thparsnrhb.append(snrhb)
     thparmeanname.append(dirtarget[i2]+ext)
     #redcisqsave.append()
     print  'blablabla after', dirtarget[i2],i2,ext,thparsub
   # 
   
   
   
   
   np.savetxt('laginfo.dat',np.array([thparsub,thparsubrms,diptestsub]))
   print 'before sadasda'
   modd = np.loadtxt('./plots/modellc.dat')
   modd_sd = np.loadtxt('./plots/modellc_sig.dat')
   tf = np.loadtxt('./plots/modeltf.dat')
   maxdel = tf[-1,0] + 1.
   mindel = tf[0,0] - 1.
   
   #find where to take limits from for stretch and os parms
   #for i3 in range(nlc):
   # np.loadtxt('../'+filedat[i3])
   
   #idxmd_save = np.where((modd[:,0] > modd[0,0] + maxdel) & (modd[:,0] < modd[-1,0] + mindel)& (modd[:,1] != 0))[0]
   #print  'piss off',idxmd_save
   idxmd = np.where((modd[:,0] > tlotemp) & (modd[:,0] < thitemp)& (modd[:,1] != 0))[0]
   idxmd_save = list(idxmd)
   
   tlomod = modd[idxmd[0],0]
   thimod = modd[idxmd[-1],0]
   moddsave = 1.*modd[idxmd_save,:]#modd[idxmd,:]
   print 'piss off2',np.shape(modd_sd),np.shape(modd)
   modd_sd_save = 1.*modd_sd[idxmd_save,:]
   print 'piss off 3'
 
   #print moddsave[0,0],moddsave[-1,0],'plot limitssssss!'
   modd = modd[idxmd,1:]
   
 
   print 'after dssd'
   
   osptemp = np.median(modd,axis=0)
   if (osptemp[0] != osptemp[0]):
    pass
   else:
    osp = np.median(modd,axis=0)
    
    #np.std(modd,axis=0)
    nmod = np.shape(modd)[1]
    stp=np.zeros(0)
    for im in range(nmod):
     stp = np.append(stp,np.abs(stat_uncert(modd[:,im])[1]))
    
    
   
   
   str = 1.
   osr = 0.
   
 
   if ((version == 3) or (version ==2)):
    #find reference light curve idx in reamnames file
    for il in range(nlc):
     check = strref in filedat[il]
     ospref[il,0] = osp[il]
     stpref[il,0] = stp[il]
     if (check ==1):
      str = stp[il]
      osr = osp[il]
      
  
  
  
  
   nfd = len(filedat)
   for id in range(nfd):
    a =  dirtarget[i2]+' '+filedat[id]+' '+np.str(ospref[id,0])+' '+np.str(ospref[id,1])+' '+np.str(stpref[id,0])+' '+np.str(stpref[id,1])+' '+np.str(erp[id,0])+' '+np.str(erp[id,1])+' \n'
    #print 'during sum dssd',id,nfd,  a 
    datsum.append(a)
   print 'lc"s...',filedat[:]
   print 'os"s...',osp
   print 'st:s...',stp
   print 'evaluated between times',tlomod,thimod
   print ''
    
  
   
   
 
   #print 'is this working figure plot', nlc, filedat
   fig = plt.figure()
   ax1 = plt.subplot(111)
   ax1.set_xlabel('Time (days)')
   ax1.set_ylabel('Normalized flux')
   
   #print stp
   #print osp
   #print erp[:,0]
   #print 'wait here'
   #raw_input()
   for i3 in range(nlc):
    
    
    
    datin = np.loadtxt('../'+filedat[i3])
    #print filedat[i3], osp[i3,0],stp[i3,0],osr,str
    #cream adds 2x minval to light curves f they have -ve values remove this effect here
    datmin = np.min(datin[:,1])
    ndown = np.shape(datin[:,0])[0]
    dat = np.hstack((datin,np.ones((ndown,2))))
    
    if (sub2min == 1):
     if (datmin < 0):
      dat[:,1] = dat[:,1] - 2*datmin
    
    datref = np.array(dat)
    #print 'before subtraction mean', np.mean(dat[:,1]), osp[i3],filedat[i3], os.getcwd()
    
    
    if (wav[i3] > 0):
     #print filedat[i3],i3,dat[:,1].mean(),moddsave[:,i3+1].mean(),'whats goiing on now',osp[i3],osr,stp[i3],str
     #raw_input()
     moddsave[:,i3+1] = (moddsave[:,i3+1] - osp[i3]) * str/stp[i3] + osr
     modd_sd_save[:,i3+1] = (modd_sd_save[:,i3+1]) * str/stp[i3]
     dat[:,1] = (dat[:,1] - osp[i3]) * str/stp[i3] + osr
     #print 'after rescaling...',i3,wav[i3],filedat[i3],np.median(dat[:,1])
     #raw_input()
     dat[:,4] = np.sqrt(ve[i3] + (erp[i3][0]*dat[:,2])**2)*str/stp[i3]
     dat[:,2] = dat[:,2] * str/stp[i3]
     dat[:,3] = dat[:,2] * erp[i3][0]
    else:#if blr light curve do not rescale 
     #moddsave[:,i3+1] = (moddsave[:,i3+1] - osp[i3]) * str/stp[i3] + osr
     dat[:,4] = np.sqrt(ve[i3] + (erp[i3][0]*dat[:,2])**2)
     dat[:,2] = dat[:,2]
     dat[:,3] = dat[:,2] * erp[i3][0]
 
    
    
    
    
    #print 'after subtraction mean', np.mean(dat[:,1]),dat.shape
    #print i3 in idxblr,i3,idxblr
    if (i3 not in idxblr):
     ax1.errorbar(dat[:,0], dat[:,1], dat[:,2], ls = '',label=filedat[i3])
    #print 'after plot'
     datcomb = np.vstack((datcomb,dat))
     np.savetxt('merged_'+filedat[i3],dat)
     
     #print 'offsetref',ospref
     #print 'stretchref',stpref
     #print osr,'offsets',osp
     #print osp,'stretches', stp
    else:
     np.savetxt('blr_'+filedat[i3],dat)
     #print 'doing rcnow normal errors',i3,idxblr
     rcnow = list(myredcisq(dat[:,0],dat[:,1],dat[:,2],moddsave[:,0],moddsave[:,i3+1]))
     #print rcnow
     #print ''
     #print 'doing rcnow modified errors'
     rcnow2 = list(myredcisq(dat[:,0],dat[:,1],dat[:,4],moddsave[:,0],moddsave[:,i3+1]))
     
     
     
     
     #print rcnow2
     #plt.close()
     #plt.errorbar(dat[:,0],dat[:,1],dat[:,4],color='b')
     #plt.plot(moddsave[:,0],moddsave[:,i3+1],color='r')
     #plt.show()
 
     ncdat = np.shape(dat[:,0])[0]
     
     redcisqsave.append(rcnow+rcnow2+[ncdat])
     
     #print 'after that'
    #print 'after save'
   plt.legend(fontsize='xx-small')
   if (showplot==1):
    plt.show()
   else:
    plt.savefig('merged.pdf')
   print 'afterplot',os.getcwd() 
   
   #ossave = np.ones((nlc,2))
   #ossave[:,0] = osp
   np.savetxt('./plots/offset.dat',ospref)
   np.savetxt('./plots/stretch.dat',stpref)
   np.savetxt('./plots/echolc_post.dat',moddsave)
   np.savetxt('./plots/echolc_error.dat',modd_sd_save)
   np.savetxt('./plots/tf_post.dat',tf)  
   
   #plt.show()
   #sys.exit()
   idxsort = np.argsort(datcomb[:,0])
   datcomb = datcomb[idxsort,:]
   print 'saving merged lightcurves',os.getcwd()
   np.savetxt('comb_merged_lc.dat',datcomb)
   #print 'after save comb'
  
  
  except:
   targetfail.append(dirtarget[i2])
   print 'failed', dirtarget[i2],os.getcwd()
  
  print 'current dir',os.getcwd()
  print 'changing to',dirall[i1]
  os.chdir(dirall[i1])
  print 'fifi it work?',os.getcwd(),i1,i2
  #os.chdir('../')
 
os.chdir(pwd)
#try:
os.system('rm -rf '+dirmergesave)
#except:
# pass









f = open('fail_list.dat','w')
for item in targetfail:
  f.write("%s\n" % item)
f.close()

if (len(targetfail) > 0):
 for fnow in targetfail:
  print fnow
 print 'the above targets failed to merge, please remove them from the folders and re-run the code'


os.system('mkdir '+dirmergesave)
os.chdir('./'+dirmergesave)
print os.getcwd()
for i in range(nd):
 print 'copying ',dirall[i], ' to '+dirmergesave
 os.system('cp -rf '+dirall[i]+' ./')







#remove unecessary files
fileshit = ['corgrey_full.PS',
'corgrey_main.PS',
'cream_fluxflux.dat',
'cream_furparms.dat',
'cream_tfparms.dat',
'outputpars2.dat',
'outputpars3.dat',
'fileinfo.dat',
'outputbackup_*',
'outputpars.dat',
'testbofs.dat',
'cream_osparms.dat',
'cream_stretchparms.dat',
'xray_plot_mod.dat',
'cream_redcisq.dat',
'pythoncov.dat',
'../cream_var.par',
'../cream_se_prior.par',
'./plots/*.PS',
#'outputpars_th.dat',
'outputpars_varexpand.dat',
'../ARGOS_catalogue.dat']

#os.system('cd ./cream_merged')
dir = glob.glob('*/')

if (test ==1):
 dir = [dir[-1]]
 
 
nd = len(dir)
for i in range(nd):
 os.chdir(dir[i])
 targ = glob.glob(targsearch)
 if (test ==1):
  targ = [targ[-1]]
 
 nt = len(targ)
 pwdnow = os.getcwd()
 for i2 in range(nt):
  
  if (targ[i2] in targetfail):
   continue
  os.chdir(pwdnow + '/'+targ[i2])
  
  try:
   op = glob.glob('output_*')
   #print 'now in ',os.getcwd()
   cdp= glob.glob('output_*')
   cdpos = [float(''.join(re.findall('\d+',sr))) for sr in cdp]
   cdpossort = np.argsort(cdpos)
   idxrecent = cdpossort[-1] 
   #remove old runs to save space
   ndpos = len(cdpos)
   cdnow = cdp[idxrecent]
    
   
   nop = len(op)
   if (nop > 1):
    for iop in range(nop-1):
     os.system('rm -rf '+cdp[cdpossort[iop]])
    #for opnow in op[:-1]:
    # os.system('rm -rf '+)
   
   
   
   #try:
   #print 'trying to do something in ',os.getcwd()
   #print 'whats in here?' 
   #os.system('ls')
   #print 'print about to change dir to ',cdnow
   
   #print 'copying *.dat from '+cdp[cdpossort[-1]]
   os.chdir(cdnow)
   #print os.getcwd(),'ararar'
   os.system('ls *.dat')
 
   for filenow in fileshit: 
    os.system('rm '+filenow)
    
   os.system('ls *.dat')
   print ''
   os.system('cp *.dat ../')
   if ((version == 3) or (version ==2)):
    os.system('cp *.pdf ../')
    os.system('cp ./plots/*0.PS ../')
    os.system('cp ./plots/bofplot.PS ../')
    os.system('cp ./plots/echolc_post.dat ../')
    os.system('cp ./plots/echolc_error.dat ../')
    os.system('cp ./plots/offset.dat ../')
    os.system('cp ./plots/stretch.dat ../')
   
   
   os.chdir('../')
   
   if (version == 2):
    os.system('rm *.dat')
   
   os.system('rm -rf output_*')
   #except:
   # pass
   os.chdir('../')
  except:
   continue 
 os.chdir('../')

#
##write a file containing the failed targets

f = open('fail_list.dat','w')
for item in targetfail:
  f.write("%s\n" % item)
f.close()


#make a tar folder for email
os.chdir(pwd)


#just 'comb_merged_lc.dat' rsync -e ssh -avS ./cream_merged ds207@thuban.st-andrews.ac.uk:/home/star2/ds207/ --exclude '*.PS' --exclude '*.pdf' --exclude '*sub50*' --exclude '*_hb_*' --exclude 'creamnames.dat' --exclude '*.txt' --exclude '*parms.dat' --exclude 'laginfo.dat' --exclude '*bok*' --exclude '*cfht*' --exclude '*spec*'
#if want to upload light curves also, do not include the final 3 excludes
if (version == 2):
 os.system('rsync -e ssh -avS '+dirmergesave+' ds207@thuban.st-andrews.ac.uk:/home/star2/ds207/www/')
elif (version == 3):
 os.system('tar czf '+dirmergesave+'_specref.tar.gz '+dirmergesave)
elif (version == 1):
 os.system('tar czf '+dirmergesave+'.tar.gz '+dirmergesave)
elif (version == 4):
 os.system('rm -rf '+dirmergesave) 
 



try:
 thparmeangori = np.array(thparmeangori)
 #make a plot of the centroids of the hbeta lags
 fig = plt.figure()
 ax1 = fig.add_subplot(111)
 ax1.hist(thparmeansave,bins=50)
 ax1.set_xlabel('mean lag (days)')
 ax1.set_ylabel('number')
 ylim = ax1.get_ylim()
 ax1.plot([0,0],[ylim[0],ylim[1]],color='k')
 plt.savefig('hbeta_cream_lag_hist_comb.pdf')
except:
 print 'unable to make histogram of lags... maybe you are only merging in this run and have not set any top hat response functions'


#make a histogram that separates teh g and i lags
try:
 fig = plt.figure()
 ax1 = fig.add_subplot(111)
 idxg = list(np.where(thparmeangori == 1)[0])
 idxi = list(np.where(thparmeangori == 2)[0])
 thparmeansave = np.array(thparmeansave)
 thparrmssave = np.array(thparrmssave)
 thparsnrhb = np.array(thparsnrhb)
 
 ax1.hist(thparmeansave[idxg],bins=50,color='b',histtype='step',label='g')
 ax1.hist(thparmeansave[idxi],bins=50,color='r',histtype='step',label='i')
 ax1.set_xlabel('mean lag (days)')
 ax1.set_ylabel('number')
 ylim = ax1.get_ylim()
 ax1.plot([0,0],[ylim[0],ylim[1]],color='k')
 plt.legend()
 plt.savefig('hbeta_cream_lag_hist_ind.pdf')



 #make a signal to noise vs lag scatter plot similar to kate grier's
 #make a histogram that separates teh g and i lags
 fig = plt.figure()
 ax1 = fig.add_subplot(111)
 ax1.scatter(thparmeansave[idxg],thparsnrhb[idxg],color='b',label='g',lw=0)
 ax1.scatter(thparmeansave[idxi],thparsnrhb[idxi],color='r',label='i',lw=0)

 ylims = ax1.get_ylim()
 ax1.set_ylim([ylims[0],ylims[1]])
 ax1.plot([0,0],[ylims[0],ylims[1]],color='k')
 ax1.set_ylabel('SNR(line) = (Max flux - Min flux)/Median Error')
 ax1.set_xlabel('CREAM lag (days)')
 plt.savefig('hbeta_cream_lag_snr.pdf')
except:
 pass



fig = plt.figure()
ax1 = fig.add_subplot(111)
ax1.scatter(thparmeansave,thparmeansave/thparrmssave)
ax1.set_xlabel('mean lag (days)')
ax1.set_ylabel(r'$\langle \tau \rangle$ / rms $\tau$')
ylim = ax1.get_ylim()
ax1.plot([0,0],[ylim[0],ylim[1]],color='k')
plt.savefig('hbeta_cream_lag_scatter.pdf')

nsum = len(datsum)
f = open('summary.txt','w')
for i in range(nsum):
 f.write(datsum[i])
f.close()
#nfail = len(thfailsave)
#save the failed entries to a file
#f = open('faillist.txt','w')
#for i in range(nfail):
# f.write(thfailsave[i]+'\n')
#f.close()

os.system('cp *.pdf ./'+dirmergesave+'/')
os.system('cp summary.txt ./'+dirmergesave+'/')

#thparmeanname
nnam = len(thparmeanname)


#ncisqsave
ncs = len(redcisqsave)

if (ncs < nnam):
 redcisqsave = [[0,0,0,0,0]]*nnam

#also make a latex table
#make for g and i band lags
try:
 for filtnow in ['g','i']:
  dt = []
  ds = []
  dattab_ha    = np.ones((0,6))*-1.
  dattab_ha_sd = np.ones((0,6))*-1.
  dattab_hb    = np.ones((0,6))*-1.
  dattab_hb_sd = np.ones((0,6))*-1.
  dattab_mg2    = np.ones((0,6))*-1.
  dattab_mg2_sd = np.ones((0,6))*-1.
  str_replace = ['']*6
  dnow    =  np.ones(6)*-1.
  dnow_sd =  np.ones(6)*-1.
  num_ha = []
  num_hb = []
  num_mg2 = []
  tittab_hb=[]
  tittab_ha=[]
  tittab_mg2=[]
  print 'making tex file'
  for i in range(nnam):
   #table for h beta and ha lags
   dnow[1] = thparmeansave[i] 
   dnow_sd[1] = thparrmssave[i] 
   dnow[2] = redcisqsave[i][1]
   dnow[3] = redcisqsave[i][2]
   dnow[4] = redcisqsave[i][4]
   dnow[5] = diptestsave[i]
   print thparmeansave[i],redcisqsave[i]
   if (('hb' in thparmeanname[i]) and (filtnow in thparmeanname[i])):
    dattab_hb = np.vstack((dattab_hb,dnow))
    dattab_hb_sd = np.vstack((dattab_hb_sd,dnow_sd)) 
    tittab_hb.append(thparmeanname[i][:5]) 
    num_hb.append(int(thparmeanname[i][2:5]))
    #num_hb.append(int(filter(str.isdigit,thparmeanname[i])))
   elif (('ha' in thparmeanname[i])  and (filtnow in thparmeanname[i])):
    dattab_ha = np.vstack((dattab_ha,dnow))
    dattab_ha_sd = np.vstack((dattab_ha_sd,dnow_sd))  
    tittab_ha.append(thparmeanname[i][:5]) 
    num_ha.append(int(thparmeanname[i][2:5]))
   elif (('mg2' in thparmeanname[i])  and (filtnow in thparmeanname[i])):
    dattab_mg2 = np.vstack((dattab_mg2,dnow))
    dattab_mg2_sd = np.vstack((dattab_mg2_sd,dnow_sd))  
    tittab_mg2.append(thparmeanname[i][:5]) 
    num_mg2.append(int(thparmeanname[i][2:5]))
    #num_ha.append(int(filter(str.isdigit,thparmeanname[i])))
 
  #sort targets into ascending order
  idx_ha = np.argsort(np.array(num_ha))
  idx_hb = np.argsort(np.array(num_hb))
  dattab_hb = dattab_hb[idx_hb,:]
  dattab_hb_sd = dattab_hb_sd[idx_hb,:]
  dattab_ha = dattab_ha[idx_ha,:]
  dattab_ha_sd = dattab_ha_sd[idx_ha,:]
  tittab_ha = list(np.array(tittab_ha)[idx_ha])
  tittab_hb = list(np.array(tittab_hb)[idx_hb])
  
  colhead  = ['Target','$\\langle \\tau \\rangle$','$\\chi^2/n$','$\\chi^2/(nf^2)$','n','Dip test']
  colunits = ['','(days)','','','','']
  ndp = [0,2,2,2,0,3]
  
  str_replace[0]=tittab_ha
  try:
   mytextable(datin=dattab_ha,opfile='ha_tab_'+filtnow,caption=filtnow+' band H$\\alpha$ lag information ',colheadin=colhead,ndpin=ndp,datsd=dattab_ha_sd,colunits=colunits,str_rep_in=str_replace,sideways=0,aw='-3.7cm')
  except:
   pass
 
  str_replace[0]=tittab_hb
  mytextable(datin=dattab_hb,opfile='hb_tab_'+filtnow,caption=filtnow+' band H$\\beta$ lag information ',colheadin=colhead,ndpin=ndp,datsd=dattab_hb_sd,colunits=colunits,str_rep_in=str_replace,sideways=0,aw='-3.7cm')
except:
 pass 
 



f = open('lagsum.txt','w')

header = 'target    ha_or_hb_or_mg2 	lagmean		lagrms		chisq		chiq_n		chisq_newsig	chisq_newsig_n	n	diptest\n'    
f.write(header)
for i in range(nnam): 
 f.write(thparmeanname[i]+' '+np.str(thparmeansave[i])+' '+np.str(thparrmssave[i])+ ' '+np.str(redcisqsave[i][0])+' '+np.str(redcisqsave[i][1])+' '+np.str(redcisqsave[i][2])+' '+np.str(redcisqsave[i][3])+' '+np.str(redcisqsave[i][4])+' '+np.str(diptestsave[i])+'\n')
f.close() 
 
os.system('cp lagsum.txt ./'+dirmergesave+'/')


 
#
#                       
#
#
#
#
##
##
##
##
##
##