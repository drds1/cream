#new 7/7/2015 creamconvert_extra is a list of multiplicative conversions to apply to each wavelength unique light curve (if need to change units)

import numpy as np
import os
import glob

#script to conver output files from cream into a format for the fluxflux analysis

#if norm = 1 then do flux flux analysis using normalised units 
#this just tets for linearity. The slopes of any f vs X lines lose their meaning if using this setting
norm = 0

#if using within cream, just set dir = './' as we will already be inside plot directory
dir = './'#'/Users/ds207/Documents/standrews/sta/fort/fortcode/mcmcmulti3/stormlc_sep4_final_septel/output_20160122_006/plots/'


#copy latest results from rigel
#a = 'rsync -e ssh -avS ds207@rigel.st-andrews.ac.uk:/data2/ds207/fortcode/mcmcmultinew/stormlc_sep4_final_septel/output_20160122_006 '+dir+'../../'
#print a
#os.system(a)



pwd = os.getcwd()




#load inferred driving light curve
x = np.loadtxt(dir+'../xray_plot_mod.dat')
xsd = 0.5*(x[:,3]-x[:,1])
nsd = np.shape(x[:,0])[0]
datx = np.zeros((nsd,3))
datx[:,0] = x[:,0]
datx[:,1] = x[:,2]
datx[:,2] = xsd
np.savetxt('filedrive.txt',datx)

#load offset parameters
dos = np.loadtxt(dir+'../cream_osparms.dat')
dos = np.vstack((np.zeros((0,2)),dos))
ofs = dos[:,0]
sigofs = dos[:,1]

#load stretch parameters
ds = np.loadtxt(dir+'../cream_stretchparms.dat')
ds = np.vstack((np.zeros((0,2)),ds))
stretch = ds[:,0]
sigstretch = ds[:,1]



#load the echo light curve data and combine if necessary
#filenames
os.chdir(dir)
with open('savelc_list.txt') as f:
 lclist = f.read().splitlines()
 f.close() 
lclist = [x.strip(' ') for x in lclist]

#load error bar expansion parameters and wavs
datse = np.loadtxt('../outputpars3.dat')
datse = np.vstack((np.zeros((0,3)),datse))
wavs  = datse[:,0]
se    = datse[:,1]
nwavs = np.shape(wavs)[0]
wavold = wavs[0]




datlc = np.loadtxt(lclist[0])
datlc[:,2] = datlc[:,2]*se[0]
wavu = []
#wavu.append(wavold)
idxu = []
#idxu.append(0)
fnamesave = []
for i in range(nwavs):
 wavnew = wavs[i]
 if ((wavnew == wavold) & (i > 0)):
  datlcnew = np.loadtxt(lclist[i])
  datlcnew[:,2] = datlcnew[:,2]*se[i]
  datlc = np.vstack((datlc,datlcnew))
  if (i == nwavs-1):
   fname = 'savelc_'+str(wavold)+'.txt'
   np.savetxt(pwd+'/'+fname,datlc)
   fnamesave.append(fname)
 else:
  idxs = np.argsort(datlc[:,0])
  idxu.append(i)
  datlc[:,:] = datlc[idxs,:]
  fname = 'savelc_'+str(wavold)+'.txt'
  fnamesave.append(fname)
  np.savetxt(pwd+'/'+fname,datlc)
  wavu.append(wavnew)
  datlc = np.loadtxt(lclist[i])
  datlc[:,2] = datlc[:,2]*se[i]
  wavold = wavnew
  #print wavold, lclist[i],np.mean(datlc[:,1]), np.median(datlc[:,1])
 #print wavold, np.shape(datlc[:,0])[0], i, nwavs
nwavu = len(wavu)
os.chdir(pwd)


#save idxu
f = open('fileidxu.txt','w')
for i in range(nwavu):
 f.write(str(idxu[i]) +'\n')
f.close()



#load inferred echo light curves
modlc = np.loadtxt(dir+'modellc.dat')
tmod  = modlc[:,0]
lc    = modlc[:,1:]



try:
 siglc = np.loadtxt(dir+'modellc_sig.dat')[:,1:]
except:
 siglc = 0.0*lc
#save these
lcsave = []
lcsigsave = []
for i in range(nwavu):
 lcsave.append(lc[:,idxu[i]])
 lcsigsave.append(siglc[:,idxu[i]])
lcsave = np.array(lcsave).transpose()
lcsigsave = np.array(lcsigsave).transpose()
 
 

#perform unit conversions if necessary 0 = no change, 1 = mjy to ergs^-1^cm^-2hz^-1sr^-1/10^-14, 2 = ergs to mjy, 
convu = np.ones(nwavu)
try:
 from creamconvert_extra import *
except:
 pass
 
for i in range(nwavu):
 lcsave[:,i] = lcsave[:,i]*convu[i]
 lcsigsave[:,i] =lcsigsave[:,i]*convu[i]
  




#change offset and stretch parameters based on model rather than cream values

ttemp = np.zeros(0)
idctemp = 0
ic = 0
idxblr = [i for i in range(len(wavu)) if wavu[i] == -1]
for ftemp in fnamesave:
 if (idctemp not in idxblr):
  ttemp = np.concatenate((ttemp,np.loadtxt(ftemp)[:,0]))
  ic = ic + 1

#if only have blr light curves then use those
if (ic == 0):
 for ftemp in fnamesave:
  ttemp = np.concatenate((ttemp,np.loadtxt(ftemp)[:,0]))





tlotemp = np.min(ttemp)
thitemp = np.max(ttemp)  
ofs = []
sigofs = []
stretch = []
sigstretch = []
idxmdsave = []
for i in range(nwavu):
 modnow = lcsave[:,i]
 idxmd = np.where((tmod > tlotemp) & (tmod < thitemp) & (lcsave[:,i] != 0) & (lcsave[:,i] == lcsave[:,i]))[0]
 nnow  = np.shape(idxmd)[0]
 ossd_now = np.sum( lcsave[idxmd,i]**2 )/nnow
 osnow  = np.median( lcsave[idxmd,i] )
 sdnow  = np.std( lcsave[idxmd,i] )
 sdsd_now = np.sqrt( np.sum( 4*(lcsave[idxmd,i] - osnow)**2 *(lcsigsave[idxmd,i]**2 + osnow**2) ) ) /np.sqrt(nnow)
 ofs.append( osnow )
 sigofs.append( ossd_now )
 stretch.append( sdnow )
 sigstretch.append( sdsd_now )
 print osnow,ossd_now,nnow,wavu[i],i,'report'
 idxmdsave.append(idxmd)
 idxu = np.arange(nwavu)
  
  
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#!!!!!!!!!!!!!!!! change offsets and stretch parameters to normalised units !!!!!!!!!!!!!!!!!!!!!!!!
#!!!!!!!!!!!!!!!! Only do this if norm == 1!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  
if (norm == 1):   
 sdave = np.mean(stretch)
 for i in range(nwavu):
  lcsave[:,i] = (lcsave[:,i]-ofs[i])/stretch[i] + 1.*i
  lcsigsave[:,i] = lcsigsave[:,i]/stretch[i]
  fnow = fnamesave[i]
  dnow = np.loadtxt(fnow)
  dnow[:,1] = (dnow[:,1]-ofs[i])/stretch[i] + 1.*i
  dnow[:,2] = dnow[:,2]/stretch[i]
  np.savetxt(fnow,dnow) 
  
np.savetxt('filelcmod.dat',lcsave) 
np.savetxt('filelcmod_sig.dat',lcsigsave) 

#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!








#make files storing wavelengths offsets and filenames
f = open('filewav.txt','w')
for i in range(nwavu):  
 f.write(str(wavu[i])+'\n')
f.close()
f = open('fileos.txt','w')
for i in idxu:
 f.write(str(ofs[i])+' '+str(sigofs[i])+' '+str(stretch[i])+' '+str(sigstretch[i])+'\n')
f.close()
f = open('filelcname.txt','w')
for i in range(nwavu):
 f.write(fnamesave[i]+'\n')
f.close()

  
  
  
  
  
  

