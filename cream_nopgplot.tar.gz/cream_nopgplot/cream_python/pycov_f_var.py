import numpy as np
import matplotlib.pylab as plt
import mycorner_jul6_16 as mc
import os






#load text
filesave = '../outputpars2.dat'
fsvar = '../outputpars_varexpand.dat'

datsv = np.loadtxt(fsvar,ndmin=2)
dater = np.loadtxt(filesave,ndmin=2)

nits,nlc = np.shape(datsv)
dat = np.zeros((nits,2*nlc))
dat[:,:nlc] = dater[:,-nlc:]
dat[:,nlc:] = datsv


#lab = ['b6s','b7s','f1s','f2s','sps','b6o','b7o','f1o','f2o','spo','b6e','b7e','f1e','f2e','spe']
lab = []
npar = np.shape(dat[0,:])[0]
nits  = np.shape(dat[:,0])[0]
npar_sub = 2
ntel = npar/npar_sub

for i in range(npar):
 if (i < ntel):
  labnow = str(i + 1)+'e'
 else:
  labnow = str(i-ntel+1)+'v'
 lab.append(labnow)

if (nits > 500):
 datin = dat[::50,:]
else:
 datin = dat[:,:]

a=mc.corner_1(datin, weights=None, labels=lab, extents=None, truths=None,
           truth_color="#4682b4", scale_hist=False, quantiles=[],
           verbose=True, plot_contours=False, plot_datapoints=True,
           fig=None,header=[],sigconts=[1],figname='covplot_se_var.pdf',skip=1, xti=[],yti=[],annotate=[])


#save correlation matrix
np.savetxt('pycov_f_var.dat',np.corrcoef(np.transpose(datin)))

#save mean and rms for all 15 parameters
datmeansd = np.ones((npar,2))
f = open('pycov_f_var_meansd.dat','w')
for i in range(npar):
 datmeansd[i,0] = np.mean(datin[:,i])
 datmeansd[i,1] = np.std(datin[:,i])
 f.write(lab[i]+' '+str(datmeansd[i,0])+' '+str(datmeansd[i,1])+'\n')
f.close()


a = np.arange(ntel+2)
alab = list(a)
alab = map(str,alab)
alab[0]=''
alab[-1]=''

#make error bar plots for the mean and sd of teh offset, stretch and error bar expansion parameters
xa  = np.arange(ntel)+1
fig = plt.figure()
ax1 = fig.add_subplot(211)
ax1.errorbar(xa,datmeansd[:ntel,0],datmeansd[:ntel,1])

ymin = np.min(datmeansd[:ntel,0] - datmeansd[:ntel,1])
ymax = np.max(datmeansd[:ntel,0] + datmeansd[:ntel,1])
ax1.set_ylim([ymin/1.1,ymax*1.1])
ax1.set_xticklabels(alab)
ax1.set_xticks(a)
ax1.set_xlabel('Light Curve Number')
ax1.set_ylabel('Error bar rescale')
ax2 = fig.add_subplot(212)
ax2.errorbar(xa,datmeansd[ntel:2*ntel,0],datmeansd[ntel:2*ntel,1])
ax2.set_xlabel('Light Curve Number')
ax2.set_ylabel('Extra Variance')
ymin = np.min(datmeansd[ntel:,0] - datmeansd[ntel:,1])
ymax = np.max(datmeansd[ntel:,0] + datmeansd[ntel:,1])
ax2.set_ylim([ymin/1.1,ymax*1.1])
ax2.set_xticklabels(alab)
ax2.set_xticks(a)





#fig.tight_layout()
plt.savefig('se_var_comp.pdf')



#make plots for the parameters vs itetration number
fig = plt.figure()
ax1 = fig.add_subplot(211)
ax2 = fig.add_subplot(212)

for i in range(nlc):
 ax1.plot(dat[:,i])
 ax2.plot(datsv[:,i])
ax1.set_xlabel('iteration')
ax2.set_xlabel('iteration')
ax1.set_ylabel('error bar f parameter')
ax2.set_ylabel('extra variance parameter')

plt.savefig('se_var_lines.pdf')


#np.savetxt('pycov_f_stretch_offset_meansd.dat',datmeansd) 
 
